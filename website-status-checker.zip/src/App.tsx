/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { INITIAL_WEBSITE_DATA } from './defaultData';
import { WebsiteData, BloodDonor, MemberApplication, ContactMessage, WebsiteConfig } from './types';

// Component Imports
import Header from './components/Header';
import HeroSlider from './components/HeroSlider';
import LeaderGrid from './components/LeaderGrid';
import NoticeBoard from './components/NoticeBoard';
import GallerySection from './components/GallerySection';
import FormsSection from './components/FormsSection';
import ContactSection from './components/ContactSection';
import AdminDrawer from './components/AdminDrawer';
import Footer from './components/Footer';

export default function App() {
  // 1. Lazy state initialization from LocalStorage
  const [websiteData, setWebsiteData] = useState<WebsiteData>(() => {
    const saved = localStorage.getItem('bcl_website_data');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Increment visitor count on new session load
        parsed.config.visitorCount = (parsed.config.visitorCount || 14502) + 1;
        return parsed;
      } catch (e) {
        console.error('Error parsing website data:', e);
      }
    }
    const defaultData = { ...INITIAL_WEBSITE_DATA };
    defaultData.config.visitorCount += 1;
    return defaultData;
  });

  const [donorList, setDonorList] = useState<BloodDonor[]>(() => {
    const saved = localStorage.getItem('bcl_donor_list');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [];
  });

  const [memberApplications, setMemberApplications] = useState<MemberApplication[]>(() => {
    const saved = localStorage.getItem('bcl_member_apps');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [];
  });

  const [contactMessages, setContactMessages] = useState<ContactMessage[]>(() => {
    const saved = localStorage.getItem('bcl_contact_messages');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [];
  });

  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    const saved = localStorage.getItem('bcl_is_admin');
    return saved === 'true';
  });

  const [activeSection, setActiveSection] = useState('home');

  // 2. Sync changes back to LocalStorage
  useEffect(() => {
    localStorage.setItem('bcl_website_data', JSON.stringify(websiteData));
  }, [websiteData]);

  useEffect(() => {
    localStorage.setItem('bcl_donor_list', JSON.stringify(donorList));
  }, [donorList]);

  useEffect(() => {
    localStorage.setItem('bcl_member_apps', JSON.stringify(memberApplications));
  }, [memberApplications]);

  useEffect(() => {
    localStorage.setItem('bcl_contact_messages', JSON.stringify(contactMessages));
  }, [contactMessages]);

  useEffect(() => {
    localStorage.setItem('bcl_is_admin', String(isAdmin));
  }, [isAdmin]);

  // 3. State update helpers
  const handleEditConfig = (updatedConfig: Partial<WebsiteConfig>) => {
    setWebsiteData((prev) => ({
      ...prev,
      config: {
        ...prev.config,
        ...updatedConfig,
      },
    }));
  };

  const handleUpdateSlides = (updatedSlides: any[]) => {
    setWebsiteData((prev) => ({
      ...prev,
      slides: updatedSlides,
    }));
  };

  const handleUpdateLeaders = (updatedLeaders: any[]) => {
    setWebsiteData((prev) => ({
      ...prev,
      leaders: updatedLeaders,
    }));
  };

  const handleUpdateNotices = (updatedNotices: any[]) => {
    setWebsiteData((prev) => ({
      ...prev,
      notices: updatedNotices,
    }));
  };

  const handleUpdateNews = (updatedNews: any[]) => {
    setWebsiteData((prev) => ({
      ...prev,
      news: updatedNews,
    }));
  };

  const handleUpdateGallery = (updatedGallery: any[]) => {
    setWebsiteData((prev) => ({
      ...prev,
      gallery: updatedGallery,
    }));
  };

  const handleUpdateLeaderCategories = (updatedCategories: string[]) => {
    setWebsiteData((prev) => ({
      ...prev,
      customLeaderCategories: updatedCategories,
    }));
  };

  const handleUpdateGalleryCategories = (updatedCategories: string[]) => {
    setWebsiteData((prev) => ({
      ...prev,
      customGalleryCategories: updatedCategories,
    }));
  };

  // 4. Backup Export & Import Functions (The highly requested Admin feature)
  const handleExportData = () => {
    const fullBackup = {
      websiteData,
      donorList,
      memberApplications,
      contactMessages,
    };
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
      JSON.stringify(fullBackup, null, 2)
    )}`;
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', jsonString);
    downloadAnchor.setAttribute('download', 'hazaribagh_bcl_website_backup.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportData = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.websiteData) setWebsiteData(json.websiteData);
        if (json.donorList) setDonorList(json.donorList);
        if (json.memberApplications) setMemberApplications(json.memberApplications);
        if (json.contactMessages) setContactMessages(json.contactMessages);
        alert('অভিনন্দন! আপনার ব্যাকআপ ডাটা সফলভাবে আপলোড করা হয়েছে এবং সাইটটি আপডেট হয়েছে।');
      } catch (error) {
        alert('ত্রুটি: ব্যাকআপ ফাইলটি সঠিক নয় বা করাপ্টেড ফাইল। অনুগ্রহ করে ফাইলটি চেক করুন।');
      }
    };
    reader.readAsText(file);
  };

  const handleResetData = () => {
    setWebsiteData(INITIAL_WEBSITE_DATA);
    setDonorList([]);
    setMemberApplications([]);
    setContactMessages([]);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased text-slate-800">
      
      {/* 1. Header & Navigation */}
      <Header
        config={websiteData.config}
        onEditConfig={handleEditConfig}
        isAdmin={isAdmin}
        setIsAdmin={setIsAdmin}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />

      {/* 2. Main Page Sections */}
      <main className="flex-grow">
        
        {/* Hero Banner Slider */}
        <HeroSlider
          slides={websiteData.slides}
          onUpdateSlides={handleUpdateSlides}
          isAdmin={isAdmin}
        />

        {/* Committee & Leadership Categories Grid */}
        <LeaderGrid
          leaders={websiteData.leaders}
          onUpdateLeaders={handleUpdateLeaders}
          customCategories={websiteData.customLeaderCategories}
          onUpdateCategories={handleUpdateLeaderCategories}
          isAdmin={isAdmin}
        />

        {/* Notices Board & News Feed */}
        <NoticeBoard
          notices={websiteData.notices}
          onUpdateNotices={handleUpdateNotices}
          news={websiteData.news}
          onUpdateNews={handleUpdateNews}
          isAdmin={isAdmin}
        />

        {/* Photo and Video Gallery folders */}
        <GallerySection
          gallery={websiteData.gallery}
          onUpdateGallery={handleUpdateGallery}
          customCategories={websiteData.customGalleryCategories}
          onUpdateCategories={handleUpdateGalleryCategories}
          isAdmin={isAdmin}
        />

        {/* Membership Application & Blood Donors Forms and Data tables */}
        <FormsSection
          donorList={donorList}
          onUpdateDonors={setDonorList}
          memberApplications={memberApplications}
          onUpdateMembers={setMemberApplications}
          contactMessages={contactMessages}
          onUpdateMessages={setContactMessages}
          isAdmin={isAdmin}
        />

        {/* Direct Contact Message form & Interactive Location map */}
        <ContactSection
          config={websiteData.config}
          contactMessages={contactMessages}
          onUpdateMessages={setContactMessages}
          isAdmin={isAdmin}
        />

      </main>

      {/* 3. Global Footer with counter */}
      <Footer
        config={websiteData.config}
        isAdmin={isAdmin}
        onEditConfig={handleEditConfig}
      />

      {/* 4. Admin Settings Panel Floating Controls Drawer */}
      <AdminDrawer
        config={websiteData.config}
        onEditConfig={handleEditConfig}
        onExportData={handleExportData}
        onImportData={handleImportData}
        onResetData={handleResetData}
        isAdmin={isAdmin}
        setIsAdmin={setIsAdmin}
      />

    </div>
  );
}
