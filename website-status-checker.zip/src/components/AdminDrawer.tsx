/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings, Download, Upload, RotateCcw, X, Check, FileJson, MapPin, Mail, Phone, Map } from 'lucide-react';
import { WebsiteConfig } from '../types';

interface AdminDrawerProps {
  config: WebsiteConfig;
  onEditConfig: (updatedConfig: Partial<WebsiteConfig>) => void;
  onExportData: () => void;
  onImportData: (file: File) => void;
  onResetData: () => void;
  isAdmin: boolean;
  setIsAdmin: (isAdmin: boolean) => void;
}

export default function AdminDrawer({
  config,
  onEditConfig,
  onExportData,
  onImportData,
  onResetData,
  isAdmin,
  setIsAdmin,
}: AdminDrawerProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  // Local form states
  const [title, setTitle] = useState(config.bannerTitle);
  const [subtitle, setSubtitle] = useState(config.bannerSubtitle);
  const [address, setAddress] = useState(config.contactAddress);
  const [email, setEmail] = useState(config.contactEmail);
  const [phone, setPhone] = useState(config.contactPhone);
  const [mapUrl, setMapUrl] = useState(config.googleMapEmbedUrl);

  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isAdmin) return null;

  const handleGlobalConfigSave = (e: React.FormEvent) => {
    e.preventDefault();
    onEditConfig({
      bannerTitle: title,
      bannerSubtitle: subtitle,
      contactAddress: address,
      contactEmail: email,
      contactPhone: phone,
      googleMapEmbedUrl: mapUrl,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (confirm('আপনি কি এই ব্যাকআপ ফাইলটি আপলোড করে আপনার বর্তমান ওয়েবসাইটের সকল তথ্য ও পরিবর্তন প্রতিস্থাপন করতে চান?')) {
        onImportData(file);
      }
    }
  };

  return (
    <>
      {/* Floating Settings Button for Admin */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center space-x-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold p-4.5 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all animate-bounce"
          title="অ্যাডমিন নিয়ন্ত্রণ প্যানেল"
        >
          <Settings size={24} className="animate-spin-slow" />
        </button>
      </div>

      {/* Admin Panel Drawer Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Drawer Container */}
      <div
        className={`fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl border-l border-emerald-100 z-50 transform transition-transform duration-300 ease-in-out overflow-y-auto ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="p-6 space-y-6">
          
          {/* Drawer Header */}
          <div className="flex justify-between items-center pb-4 border-b border-gray-100">
            <div className="flex items-center space-x-2">
              <Settings className="text-emerald-700" size={22} />
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-sans">অ্যাডমিন কনট্রোল প্যানেল</h3>
                <p className="text-xs text-gray-400">কোড পরিবর্তন ছাড়াই ওয়েবসাইটের যেকোনো তথ্য নিয়ন্ত্রণ করুন।</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100 cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>

          {/* Core Feature 1: Backup & Restore */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-emerald-50 space-y-4">
            <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2 font-sans">
              <FileJson size={16} className="text-emerald-700" />
              <span>ডাটা ব্যাকআপ ও রিস্টোর (Backup & Restore)</span>
            </h4>
            <p className="text-xs text-gray-500 leading-relaxed">
              যেহেতু এই ওয়েবসাইটটি সম্পূর্ণ স্ট্যাটিক এবং ক্লায়েন্ট-সাইডে কাজ করে, আপনার করা সব পরিবর্তন (যেমন ছবি, নোটিশ, নেতা) আপনার ব্রাউজারে সংরক্ষিত থাকে। অন্য কম্পিউটারে বা অনলাইনে পাবলিশ করতে ডাটা ব্যাকআপ ডাউনলোড করুন এবং আপলোড করুন।
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={onExportData}
                className="flex items-center justify-center space-x-1.5 px-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md transition-colors cursor-pointer"
                title="ব্যাকআপ ফাইল ডাউনলোড করুন"
              >
                <Download size={14} />
                <span>ডাউনলোড করুন</span>
              </button>

              <label className="flex items-center justify-center space-x-1.5 px-3 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl text-xs shadow-md transition-colors cursor-pointer text-center">
                <Upload size={14} />
                <span>রিস্টোর আপলোড</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
            </div>

            <button
              onClick={() => {
                if (confirm('আপনি কি নিশ্চিত যে আপনার বর্তমান ওয়েবসাইটের সকল তথ্য মুছে ফেলে একদম ডিফল্ট অবস্থায় ফিরে যেতে চান?')) {
                  onResetData();
                  alert('ওয়েবসাইটটি সফলভাবে ডিফল্ট সেটিংসে ফিরানো হয়েছে!');
                }
              }}
              className="w-full flex items-center justify-center space-x-1 px-3 py-2 bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              <RotateCcw size={12} />
              <span>রিসেট করে ডিফল্ট সেটিংসে ফিরুন</span>
            </button>
          </div>

          {/* Core Feature 2: Edit Global Settings */}
          <form onSubmit={handleGlobalConfigSave} className="space-y-4">
            <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2 font-sans pb-2 border-b border-gray-50">
              <Settings size={16} className="text-emerald-700" />
              <span>গ্লোবাল টেক্সট ও সেটিংস</span>
            </h4>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">ওয়েবসাইটের নাম (প্রধান শিরোনাম)</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">উপ-শিরোনাম (যেমন: "ঢাকা মহানগর দক্ষিণ")</label>
              <input
                type="text"
                required
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <MapPin size={12} />
                <span>যোগাযোগ ঠিকানা</span>
              </label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <Phone size={11} />
                  <span>ফোন নম্বর</span>
                </label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-xs bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <Mail size={11} />
                  <span>ইমেইল</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-xs bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <Map size={12} />
                <span>গুগল ম্যাপ এমবেড লিঙ্ক (iframe src)</span>
              </label>
              <textarea
                rows={2}
                required
                value={mapUrl}
                onChange={(e) => setMapUrl(e.target.value)}
                className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-xs font-mono bg-white resize-none"
              />
            </div>

            {savedSuccess && (
              <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 animate-pulse">
                <Check size={14} className="text-emerald-600" />
                <span>তথ্যসমূহ সফলভাবে সংরক্ষণ করা হয়েছে!</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full flex items-center justify-center space-x-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3 rounded-xl text-sm shadow-md transition-colors cursor-pointer"
            >
              <Check size={16} />
              <span>পরিবর্তন সংরক্ষণ করুন</span>
            </button>
          </form>

          {/* Footer inside drawer */}
          <div className="pt-6 border-t border-gray-100 text-center text-[11px] text-gray-400">
            <span>হাজারীবাগ থানা ছাত্রলীগ ওয়েবসাইট কনট্রোল প্যানেল v১.০</span>
          </div>

        </div>
      </div>
    </>
  );
}
