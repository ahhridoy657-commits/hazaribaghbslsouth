/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MapPin, Mail, Phone, Send, CheckCircle, MessageSquare } from 'lucide-react';
import { WebsiteConfig, ContactMessage } from '../types';

interface ContactSectionProps {
  config: WebsiteConfig;
  contactMessages: ContactMessage[];
  onUpdateMessages: (updatedMessages: ContactMessage[]) => void;
  isAdmin: boolean;
}

export default function ContactSection({
  config,
  contactMessages,
  onUpdateMessages,
  isAdmin,
}: ContactSectionProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [message, setMessage] = useState('');
  
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !mobile || !message) return;

    const newMsg: ContactMessage = {
      id: `msg-${Date.now()}`,
      name,
      email: email || undefined,
      mobile,
      message,
      date: new Date().toISOString().split('T')[0],
    };

    onUpdateMessages([newMsg, ...contactMessages]);
    setIsSubmitted(true);

    // Reset Form
    setName('');
    setEmail('');
    setMobile('');
    setMessage('');

    setTimeout(() => setIsSubmitted(false), 5000);
  };

  return (
    <section id="contact" className="py-16 bg-white border-b border-emerald-100 scroll-mt-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto mb-12 text-center">
          <span className="text-emerald-700 font-bold text-sm tracking-widest uppercase bg-emerald-100 px-3 py-1 rounded-full">
            যোগাযোগ করুন
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-3 font-sans">
            আমাদের সাথে যোগাযোগ করুন
          </h2>
          <p className="text-gray-500 mt-2 text-sm sm:text-base">
            যেকোনো মতামত, পরামর্শ বা অনুসন্ধানের জন্য নিচের ফর্মটি পূরণ করে সরাসরি আমাদের বার্তা পাঠান।
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-10 items-stretch">
          
          {/* Left Column: Contact Form (7 Cols) */}
          <div className="lg:col-span-7 bg-slate-50 border border-emerald-50 rounded-3xl p-6 md:p-8 flex flex-col justify-between">
            {isSubmitted ? (
              <div className="py-16 text-center space-y-4 my-auto">
                <div className="inline-flex p-4 bg-emerald-100 rounded-full text-emerald-600 mb-2 animate-bounce">
                  <CheckCircle size={48} />
                </div>
                <h3 className="text-2xl font-black text-slate-800 font-sans">
                  বার্তাটি সফলভাবে পাঠানো হয়েছে!
                </h3>
                <p className="text-gray-500 max-w-md mx-auto text-sm md:text-base">
                  আমাদের সাথে যোগাযোগ করার জন্য ধন্যবাদ। আপনার বার্তাটি সফলভাবে অ্যাডমিন প্যানেলে জমা হয়েছে। আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।
                </p>
                <button
                  onClick={() => setIsSubmitted(false)}
                  className="px-6 py-2 bg-emerald-600 text-white rounded-xl text-sm font-semibold hover:bg-emerald-700 transition-colors"
                >
                  আরেকটি বার্তা পাঠান
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex items-center space-x-2 pb-2 border-b border-gray-100">
                  <MessageSquare className="text-emerald-700" size={20} />
                  <h3 className="text-base sm:text-lg font-bold text-slate-800 font-sans">সরাসরি মেসেজ পাঠান</h3>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">আপনার নাম <span className="text-red-500">*</span></label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                      placeholder="নাম লিখুন"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">মোবাইল নম্বর <span className="text-red-500">*</span></label>
                    <input
                      type="tel"
                      required
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                      placeholder="মোবাইল নম্বর"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">ইমেইল ঠিকানা (ঐচ্ছিক)</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                    placeholder="example@mail.com"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">আপনার বার্তা / মন্তব্য <span className="text-red-500">*</span></label>
                  <textarea
                    rows={4}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white resize-none"
                    placeholder="আপনার বার্তাটি বিস্তারিত এখানে লিখুন..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl text-sm md:text-base shadow-md transition-all transform active:scale-99 cursor-pointer"
                >
                  <Send size={16} />
                  <span>মেসেজ পাঠান</span>
                </button>
              </form>
            )}
          </div>

          {/* Right Column: Google Maps (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            
            {/* Direct Contacts Info cards */}
            <div className="bg-slate-50 border border-emerald-50 rounded-3xl p-6 space-y-4">
              <h3 className="text-sm sm:text-base font-bold text-slate-800 font-sans">থানা ছাত্রলীগ প্রধান কার্যালয়</h3>
              <div className="space-y-3 text-xs sm:text-sm text-gray-600">
                <div className="flex items-start space-x-2.5">
                  <MapPin size={16} className="text-emerald-600 shrink-0 mt-0.5" />
                  <span>{config.contactAddress}</span>
                </div>
                <div className="flex items-center space-x-2.5">
                  <Phone size={16} className="text-emerald-600 shrink-0" />
                  <a href={`tel:${config.contactPhone}`} className="hover:text-emerald-700 transition-colors font-semibold font-mono">
                    {config.contactPhone}
                  </a>
                </div>
                <div className="flex items-center space-x-2.5">
                  <Mail size={16} className="text-emerald-600 shrink-0" />
                  <a href={`mailto:${config.contactEmail}`} className="hover:text-emerald-700 transition-colors font-semibold font-mono truncate">
                    {config.contactEmail}
                  </a>
                </div>
              </div>
            </div>

            {/* Google Map iframe */}
            <div className="bg-white border border-gray-200 rounded-3xl overflow-hidden h-64 shadow-xs relative flex-1 min-h-[240px]">
              <iframe
                src={config.googleMapEmbedUrl}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Office Location Map"
                className="w-full h-full"
              />
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
