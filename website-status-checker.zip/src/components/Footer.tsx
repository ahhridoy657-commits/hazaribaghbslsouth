/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Facebook, Twitter, Youtube, Eye, Heart, MapPin, Mail, Phone, ExternalLink } from 'lucide-react';
import { WebsiteConfig } from '../types';

interface FooterProps {
  config: WebsiteConfig;
  isAdmin: boolean;
  onEditConfig: (updatedConfig: Partial<WebsiteConfig>) => void;
}

export default function Footer({ config, isAdmin, onEditConfig }: FooterProps) {
  
  const handleSocialChange = (platform: 'facebook' | 'twitter' | 'youtube', value: string) => {
    if (platform === 'facebook') onEditConfig({ socialFacebook: value });
    if (platform === 'twitter') onEditConfig({ socialTwitter: value });
    if (platform === 'youtube') onEditConfig({ socialYoutube: value });
  };

  return (
    <footer className="bg-slate-900 text-gray-300 pt-16 pb-8 border-t-4 border-emerald-600 relative overflow-hidden">
      
      {/* Decorative national flag gradient line */}
      <div className="absolute top-0 left-0 h-1.5 w-full flex">
        <div className="bg-emerald-600 h-full w-[70%]" />
        <div className="bg-red-600 h-full w-[30%]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/5">
          
          {/* Col 1: Organization brand (5 Cols) */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center space-x-3">
              <img
                src={config.logoUrl || 'https://images.unsplash.com/photo-1621640100414-03a0368c8536?q=80&w=200&auto=format&fit=crop'}
                alt="Logo"
                className="w-12 h-12 rounded-full border-2 border-emerald-500 object-cover"
              />
              <div>
                <h3 className="text-white text-lg font-black font-sans tracking-tight">
                  {config.bannerTitle}
                </h3>
                <p className="text-emerald-400 text-xs font-semibold uppercase tracking-wider">
                  {config.bannerSubtitle}
                </p>
              </div>
            </div>
            
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
              বঙ্গবন্ধুর সোনার বাংলা ও দেশরত্ন শেখ হাসিনার স্মার্ট বাংলাদেশ বিনির্মাণে হাজারীবাগ থানা ছাত্রলীগ সদা তৎপর ও প্রতিজ্ঞাবদ্ধ। শিক্ষা, শান্তি ও প্রগতির পতাকাবাহী এক অতন্দ্র প্রহরী।
            </p>

            {/* Visitor Counter */}
            <div className="inline-flex items-center space-x-2 bg-emerald-950/60 border border-emerald-900/50 px-4 py-2 rounded-xl text-xs font-semibold text-emerald-300">
              <Eye size={14} className="text-emerald-400" />
              <span>ওয়েবসাইট ভিজিটর কাউন্টার:</span>
              <span className="font-mono bg-emerald-900 px-2 py-0.5 rounded-md text-emerald-100 text-sm font-bold tracking-wider">
                {config.visitorCount.toLocaleString('bn-BD')}
              </span>
            </div>
          </div>

          {/* Col 2: Useful Section links (3 Cols) */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="text-white text-sm font-bold uppercase tracking-wider pb-2 border-b border-white/5 font-sans">
              গুরুত্বপূর্ণ লিঙ্কসমূহ
            </h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <a href="#home" className="hover:text-emerald-400 transition-colors flex items-center gap-1.5">
                  <ArrowRightIcon />
                  <span>হোম পেজ</span>
                </a>
              </li>
              <li>
                <a href="#committee" className="hover:text-emerald-400 transition-colors flex items-center gap-1.5">
                  <ArrowRightIcon />
                  <span>কমিটি ও নেতৃত্ব</span>
                </a>
              </li>
              <li>
                <a href="#notices" className="hover:text-emerald-400 transition-colors flex items-center gap-1.5">
                  <ArrowRightIcon />
                  <span>নোটিশ ও কার্যক্রম</span>
                </a>
              </li>
              <li>
                <a href="#donor-form" className="hover:text-emerald-400 transition-colors flex items-center gap-1.5">
                  <ArrowRightIcon />
                  <span>রক্তদাতা আবেদন</span>
                </a>
              </li>
              <li>
                <a href="#member-form" className="hover:text-emerald-400 transition-colors flex items-center gap-1.5">
                  <ArrowRightIcon />
                  <span>সদস্য আবেদন</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact & Socials (4 Cols) */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-white text-sm font-bold uppercase tracking-wider pb-2 border-b border-white/5 font-sans">
              আমাদের সাথে যোগাযোগ
            </h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-start space-x-2.5">
                <MapPin size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <span>{config.contactAddress}</span>
              </li>
              <li className="flex items-center space-x-2.5">
                <Phone size={16} className="text-emerald-400 shrink-0" />
                <a href={`tel:${config.contactPhone}`} className="hover:text-emerald-400 transition-colors font-mono">
                  {config.contactPhone}
                </a>
              </li>
              <li className="flex items-center space-x-2.5">
                <Mail size={16} className="text-emerald-400 shrink-0" />
                <a href={`mailto:${config.contactEmail}`} className="hover:text-emerald-400 transition-colors font-mono truncate">
                  {config.contactEmail}
                </a>
              </li>
            </ul>

            {/* Social Media Links */}
            <div className="pt-2 space-y-3">
              <div className="flex space-x-3">
                <a
                  href={config.socialFacebook}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  className="p-2 rounded-xl bg-white/5 hover:bg-emerald-600 text-gray-300 hover:text-white transition-all shadow-sm"
                  title="Facebook"
                >
                  <Facebook size={18} />
                </a>
                <a
                  href={config.socialTwitter}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  className="p-2 rounded-xl bg-white/5 hover:bg-emerald-600 text-gray-300 hover:text-white transition-all shadow-sm"
                  title="Twitter"
                >
                  <Twitter size={18} />
                </a>
                <a
                  href={config.socialYoutube}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  className="p-2 rounded-xl bg-white/5 hover:bg-emerald-600 text-gray-300 hover:text-white transition-all shadow-sm"
                  title="YouTube"
                >
                  <Youtube size={18} />
                </a>
              </div>

              {isAdmin && (
                <div className="space-y-1 bg-white/5 p-3 rounded-xl border border-white/5 text-xs text-left">
                  <span className="text-emerald-400 font-bold">সোশ্যাল মিডিয়া এডিট (Admin)</span>
                  <input
                    type="text"
                    value={config.socialFacebook}
                    onChange={(e) => handleSocialChange('facebook', e.target.value)}
                    className="w-full mt-1.5 px-2 py-1 bg-black/40 border border-white/10 rounded-md text-[11px] font-mono"
                    placeholder="Facebook URL"
                  />
                  <input
                    type="text"
                    value={config.socialTwitter}
                    onChange={(e) => handleSocialChange('twitter', e.target.value)}
                    className="w-full mt-1 px-2 py-1 bg-black/40 border border-white/10 rounded-md text-[11px] font-mono"
                    placeholder="Twitter URL"
                  />
                  <input
                    type="text"
                    value={config.socialYoutube}
                    onChange={(e) => handleSocialChange('youtube', e.target.value)}
                    className="w-full mt-1 px-2 py-1 bg-black/40 border border-white/10 rounded-md text-[11px] font-mono"
                    placeholder="YouTube URL"
                  />
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Copyright, Credits and Disclaimers */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center text-xs text-gray-500 gap-4">
          <p>© {new Date().getFullYear()} {config.bannerTitle}। সর্বস্বত্ব সংরক্ষিত।</p>
          <p className="flex items-center space-x-1">
            <span>নির্মিত হয়েছে</span>
            <Heart size={10} className="text-red-500 fill-red-500 animate-pulse" />
            <span>দ্বারা বাংলাদেশ ছাত্র সমাজের গৌরবময় স্বার্থে।</span>
          </p>
        </div>

      </div>
    </footer>
  );
}

// Simple Helper Icon
function ArrowRightIcon() {
  return (
    <svg
      className="w-3 h-3 text-emerald-500 shrink-0"
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7" />
    </svg>
  );
}
