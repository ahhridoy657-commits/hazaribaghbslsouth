/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HeartHandshake, UserPlus, ClipboardList, CheckCircle, Trash2, Inbox, Mail, Phone, Calendar, MapPin, School, FileText, ArrowRight } from 'lucide-react';
import { BloodDonor, MemberApplication, ContactMessage } from '../types';

interface FormsSectionProps {
  donorList: BloodDonor[];
  onUpdateDonors: (updatedDonors: BloodDonor[]) => void;
  memberApplications: MemberApplication[];
  onUpdateMembers: (updatedMembers: MemberApplication[]) => void;
  contactMessages: ContactMessage[];
  onUpdateMessages: (updatedMessages: ContactMessage[]) => void;
  isAdmin: boolean;
}

export default function FormsSection({
  donorList,
  onUpdateDonors,
  memberApplications,
  onUpdateMembers,
  contactMessages,
  onUpdateMessages,
  isAdmin,
}: FormsSectionProps) {
  const [activeFormTab, setActiveFormTab] = useState<'donor' | 'member'>('donor');
  const [activeAdminTab, setActiveAdminTab] = useState<'donors' | 'members' | 'messages'>('donors');
  
  // Submission success animation screens
  const [submittedDonor, setSubmittedDonor] = useState(false);
  const [submittedMember, setSubmittedMember] = useState(false);

  // Blood Donor Form State
  const [donorName, setDonorName] = useState('');
  const [donorMobile, setDonorMobile] = useState('');
  const [donorGroup, setDonorGroup] = useState('O+');
  const [donorAddress, setDonorAddress] = useState('');
  const [donorEmail, setDonorEmail] = useState('');
  const [donorComments, setDonorComments] = useState('');

  // Member Form State
  const [memberName, setMemberName] = useState('');
  const [memberParentName, setMemberParentName] = useState('');
  const [memberDob, setMemberDob] = useState('');
  const [memberInstitution, setMemberInstitution] = useState('');
  const [memberClass, setMemberClass] = useState('');
  const [memberMobile, setMemberMobile] = useState('');
  const [memberEmail, setMemberEmail] = useState('');
  const [memberAddress, setMemberAddress] = useState('');
  const [memberPhoto, setMemberPhoto] = useState('');
  const [memberNid, setMemberNid] = useState('');

  const submitDonorForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!donorName || !donorMobile || !donorAddress) return;

    const newDonor: BloodDonor = {
      id: `donor-${Date.now()}`,
      name: donorName,
      mobile: donorMobile,
      bloodGroup: donorGroup,
      address: donorAddress,
      email: donorEmail || undefined,
      comments: donorComments || undefined,
      date: new Date().toISOString().split('T')[0],
    };

    onUpdateDonors([newDonor, ...donorList]);
    setSubmittedDonor(true);

    // Reset Form
    setDonorName('');
    setDonorMobile('');
    setDonorAddress('');
    setDonorEmail('');
    setDonorComments('');

    setTimeout(() => setSubmittedDonor(false), 5000);
  };

  const submitMemberForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberName || !memberParentName || !memberMobile || !memberAddress || !memberNid) return;

    const newApp: MemberApplication = {
      id: `member-${Date.now()}`,
      name: memberName,
      fatherMotherName: memberParentName,
      dob: memberDob,
      institution: memberInstitution,
      classYear: memberClass,
      mobile: memberMobile,
      email: memberEmail || undefined,
      address: memberAddress,
      photoUrl: memberPhoto || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=150&auto=format&fit=crop',
      nidBirthReg: memberNid,
      status: 'pending',
      date: new Date().toISOString().split('T')[0],
    };

    onUpdateMembers([newApp, ...memberApplications]);
    setSubmittedMember(true);

    // Reset Form
    setMemberName('');
    setMemberParentName('');
    setMemberDob('');
    setMemberInstitution('');
    setMemberClass('');
    setMemberMobile('');
    setMemberEmail('');
    setMemberAddress('');
    setMemberPhoto('');
    setMemberNid('');

    setTimeout(() => setSubmittedMember(false), 5000);
  };

  const deleteDonor = (id: string) => {
    if (confirm('আপনি কি এই রক্তদাতার তথ্য মুছে ফেলতে চান?')) {
      onUpdateDonors(donorList.filter((d) => d.id !== id));
    }
  };

  const deleteMember = (id: string) => {
    if (confirm('আপনি কি এই সদস্য আবেদনটি মুছে ফেলতে চান?')) {
      onUpdateMembers(memberApplications.filter((m) => m.id !== id));
    }
  };

  const deleteMessage = (id: string) => {
    if (confirm('আপনি কি এই যোগাযোগ বার্তাটি মুছে ফেলতে চান?')) {
      onUpdateMessages(contactMessages.filter((m) => m.id !== id));
    }
  };

  const updateMemberStatus = (id: string, status: 'approved' | 'rejected') => {
    onUpdateMembers(
      memberApplications.map((m) => (m.id === id ? { ...m, status } : m))
    );
  };

  return (
    <section id="donor-form" className="py-16 bg-white border-b border-emerald-100 scroll-mt-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: Form Section (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Form Toggle Tabs */}
            <div className="flex border-b border-gray-100 pb-2 space-x-4">
              <button
                onClick={() => setActiveFormTab('donor')}
                className={`flex items-center space-x-2 pb-3 text-base sm:text-lg font-bold border-b-2 transition-all cursor-pointer ${
                  activeFormTab === 'donor'
                    ? 'border-emerald-600 text-emerald-800'
                    : 'border-transparent text-gray-400 hover:text-gray-600'
                }`}
              >
                <HeartHandshake size={20} className="text-red-500" />
                <span>রক্তদাতা রেজিস্ট্রেশন</span>
              </button>
              <button
                onClick={() => {
                  setActiveFormTab('member');
                  // update scroll anchor if needed
                  const el = document.getElementById('member-form');
                  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }}
                className={`flex items-center space-x-2 pb-3 text-base sm:text-lg font-bold border-b-2 transition-all cursor-pointer ${
                  activeFormTab === 'member'
                    ? 'border-emerald-600 text-emerald-800'
                    : 'border-transparent text-gray-400 hover:text-gray-600'
                }`}
              >
                <UserPlus size={20} className="text-emerald-600" />
                <span>নতুন সদস্য আবেদন ফরম</span>
              </button>
            </div>

            {/* Blood Donor Form Panel */}
            {activeFormTab === 'donor' && (
              <div className="bg-slate-50 border border-emerald-50 rounded-3xl p-6 md:p-8 shadow-inner animate-in fade-in duration-200">
                {submittedDonor ? (
                  <div className="py-12 text-center space-y-4">
                    <div className="inline-flex p-4 bg-emerald-100 rounded-full text-emerald-600 mb-2 animate-bounce">
                      <CheckCircle size={48} />
                    </div>
                    <h3 className="text-2xl font-black text-slate-800 font-sans">
                      রেজিস্ট্রেশন সফল হয়েছে!
                    </h3>
                    <p className="text-gray-500 max-w-md mx-auto text-sm md:text-base">
                      রক্তদাতা হিসেবে আবেদন করার জন্য আপনাকে আন্তরিক ধন্যবাদ। আপনার তথ্য আমাদের সিস্টেমে সংরক্ষিত হয়েছে। জরুরি প্রয়োজনে আপনার সাথে যোগাযোগ করা হবে।
                    </p>
                    <button
                      onClick={() => setSubmittedDonor(false)}
                      className="px-6 py-2 bg-emerald-600 text-white rounded-xl text-sm font-semibold hover:bg-emerald-700 transition-colors"
                    >
                      আরেকটি ফর্ম পূরণ করুন
                    </button>
                  </div>
                ) : (
                  <form onSubmit={submitDonorForm} className="space-y-4">
                    <div className="space-y-1">
                      <h3 className="text-lg font-bold text-slate-800 font-sans">রক্তদাতা নিবন্ধন ফরম</h3>
                      <p className="text-xs text-gray-400">আপনার এক ব্যাগ রক্ত বাঁচাতে পারে একটি মুমূর্ষু রোগীর প্রাণ। অনুগ্রহ করে সঠিক তথ্য প্রদান করুন।</p>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">রক্তদাতার নাম <span className="text-red-500">*</span></label>
                        <input
                          type="text"
                          required
                          value={donorName}
                          onChange={(e) => setDonorName(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="আপনার পূর্ণ নাম লিখুন"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">মোবাইল নম্বর <span className="text-red-500">*</span></label>
                        <input
                          type="tel"
                          required
                          value={donorMobile}
                          onChange={(e) => setDonorMobile(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="যেমন: ০১৭০০০০০০০০"
                        />
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">রক্তের গ্রুপ <span className="text-red-500">*</span></label>
                        <select
                          value={donorGroup}
                          onChange={(e) => setDonorGroup(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white cursor-pointer"
                        >
                          <option value="A+">A+ (এ পজিটিভ)</option>
                          <option value="A-">A- (এ নেগেটিভ)</option>
                          <option value="B+">B+ (বি পজিটিভ)</option>
                          <option value="B-">B- (বি নেগেটিভ)</option>
                          <option value="O+">O+ (ও পজিটিভ)</option>
                          <option value="O-">O- (ও নেগেটিভ)</option>
                          <option value="AB+">AB+ (এবি পজিটিভ)</option>
                          <option value="AB-">AB- (এবি নেগেটিভ)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">ইমেইল ঠিকানা (ঐচ্ছিক)</label>
                        <input
                          type="email"
                          value={donorEmail}
                          onChange={(e) => setDonorEmail(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="example@email.com"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">বর্তমান ঠিকানা <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        required
                        value={donorAddress}
                        onChange={(e) => setDonorAddress(e.target.value)}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                        placeholder="যেমন: হাজারীবাগ বাজার, ঢাকা"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">মন্তব্য বা অতিরিক্ত বিবরণ (ঐচ্ছিক)</label>
                      <textarea
                        rows={2}
                        value={donorComments}
                        onChange={(e) => setDonorComments(e.target.value)}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white resize-none"
                        placeholder="কবে শেষ রক্ত দিয়েছেন বা কোনো শারীরিক তথ্য থাকলে লিখুন..."
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full flex items-center justify-center space-x-2 bg-red-600 hover:bg-red-700 text-white font-bold py-3.5 rounded-xl text-sm md:text-base shadow-md transition-all transform active:scale-99"
                    >
                      <HeartHandshake size={18} />
                      <span>রক্তদাতা হিসেবে রেজিস্ট্রেশন করুন</span>
                    </button>
                  </form>
                )}
              </div>
            )}

            {/* Member Registration Form Panel */}
            {activeFormTab === 'member' && (
              <div id="member-form" className="bg-slate-50 border border-emerald-50 rounded-3xl p-6 md:p-8 shadow-inner animate-in fade-in duration-200 scroll-mt-24">
                {submittedMember ? (
                  <div className="py-12 text-center space-y-4">
                    <div className="inline-flex p-4 bg-emerald-100 rounded-full text-emerald-600 mb-2 animate-bounce">
                      <CheckCircle size={48} />
                    </div>
                    <h3 className="text-2xl font-black text-slate-800 font-sans">
                      আবেদনপত্র সফলভাবে জমা হয়েছে!
                    </h3>
                    <p className="text-gray-500 max-w-md mx-auto text-sm md:text-base">
                      হাজারীবাগ থানা ছাত্রলীগের প্রাথমিক সদস্যপদের জন্য আপনার আবেদনটি সফলভাবে সিস্টেমে রেকর্ড করা হয়েছে। থানা কমিটি তথ্য যাচাই-বাছাই করে আপনার সাথে যোগাযোগ করবে।
                    </p>
                    <button
                      onClick={() => setSubmittedMember(false)}
                      className="px-6 py-2 bg-emerald-600 text-white rounded-xl text-sm font-semibold hover:bg-emerald-700 transition-colors"
                    >
                      আরেকটি আবেদন ফরম পূরণ করুন
                    </button>
                  </div>
                ) : (
                  <form onSubmit={submitMemberForm} className="space-y-4">
                    <div className="space-y-1">
                      <h3 className="text-lg font-bold text-slate-800 font-sans">প্রাথমিক সদস্যপদ আবেদন ফরম</h3>
                      <p className="text-xs text-gray-400">বাংলাদেশ ছাত্রলীগের হাজারীবাগ থানার গর্বিত কর্মী হতে প্রয়োজনীয় তথ্য দিয়ে ফরমটি সাবমিট করুন।</p>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">আবেদনকারীর নাম <span className="text-red-500">*</span></label>
                        <input
                          type="text"
                          required
                          value={memberName}
                          onChange={(e) => setMemberName(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="আপনার সার্টিফিকেট অনুযায়ী নাম"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">পিতা ও মাতার নাম <span className="text-red-500">*</span></label>
                        <input
                          type="text"
                          required
                          value={memberParentName}
                          onChange={(e) => setMemberParentName(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="পিতার নাম, মাতার নাম"
                        />
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">জন্ম তারিখ <span className="text-red-500">*</span></label>
                        <input
                          type="date"
                          required
                          value={memberDob}
                          onChange={(e) => setMemberDob(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white cursor-pointer"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">জাতীয় পরিচয়পত্র / জন্মনিবন্ধন নম্বর <span className="text-red-500">*</span></label>
                        <input
                          type="text"
                          required
                          value={memberNid}
                          onChange={(e) => setMemberNid(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="NID বা জন্মনিবন্ধন নং"
                        />
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">শিক্ষাপ্রতিষ্ঠানের নাম</label>
                        <input
                          type="text"
                          value={memberInstitution}
                          onChange={(e) => setMemberInstitution(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="যেমন: হাজারীবাগ কলেজ"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">শ্রেণি / বর্ষ</label>
                        <input
                          type="text"
                          value={memberClass}
                          onChange={(e) => setMemberClass(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="যেমন: দ্বাদশ শ্রেণি / ২য় বর্ষ"
                        />
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">মোবাইল নম্বর <span className="text-red-500">*</span></label>
                        <input
                          type="tel"
                          required
                          value={memberMobile}
                          onChange={(e) => setMemberMobile(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="সচল মোবাইল নম্বর লিখুন"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">ইমেইল ঠিকানা</label>
                        <input
                          type="email"
                          value={memberEmail}
                          onChange={(e) => setMemberEmail(e.target.value)}
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                          placeholder="example@mail.com"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">স্থায়ী বা বর্তমান ঠিকানা <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        required
                        value={memberAddress}
                        onChange={(e) => setMemberAddress(e.target.value)}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                        placeholder="আপনার বর্তমান ও স্থায়ী ঠিকানা"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">প্রোফাইল ছবি লিংক (Image URL)</label>
                      <input
                        type="text"
                        value={memberPhoto}
                        onChange={(e) => setMemberPhoto(e.target.value)}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-sm font-mono bg-white"
                        placeholder="আপনার ছবির লিংক অথবা ব্ল্যাংক রাখুন"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full flex items-center justify-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl text-sm md:text-base shadow-md transition-all transform active:scale-99"
                    >
                      <UserPlus size={18} />
                      <span>সদস্যপদের জন্য আবেদনপত্র জমা দিন</span>
                    </button>
                  </form>
                )}
              </div>
            )}
          </div>

          {/* Right Column: Dynamic Info list panel (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Quick Stats Panel */}
            <div className="bg-emerald-800 text-white p-6 rounded-3xl space-y-4 shadow-md relative overflow-hidden">
              <div className="absolute top-0 right-0 transform translate-x-6 -translate-y-6 w-32 h-32 bg-emerald-700/30 rounded-full" />
              <div className="relative space-y-2">
                <span className="text-emerald-300 text-xs font-bold tracking-wider uppercase">সমাজসেবা ও জনকল্যাণ</span>
                <h3 className="text-xl sm:text-2xl font-black font-sans leading-snug">জরুরি রক্তের প্রয়োজনে আমরা আছি আপনার পাশে</h3>
                <p className="text-gray-200 text-xs sm:text-sm leading-relaxed">
                  হাজারীবাগ থানা ছাত্রলীগের বিশাল রক্তদাতার নেটওয়ার্ক সর্বদা যেকোনো রক্তের গ্রুপের প্রয়োজনে প্রস্তুত রয়েছে। আপনিও রক্তদাতা হিসেবে যুক্ত হোন অথবা যেকোনো রক্তের প্রয়োজনে আমাদের সাথে যোগাযোগ করুন।
                </p>
                <div className="pt-4 flex justify-between items-center text-xs font-bold border-t border-emerald-700/50">
                  <span className="text-emerald-200">মোট নিবন্ধিত রক্তদাতা:</span>
                  <span className="text-red-300 text-base">{donorList.length + 22} জন</span>
                </div>
              </div>
            </div>

            {/* Instruction Panel */}
            <div className="bg-slate-50 border border-emerald-50 rounded-3xl p-6 space-y-4">
              <h3 className="text-sm sm:text-base font-bold text-slate-800 flex items-center gap-2 font-sans">
                <ClipboardList size={18} className="text-emerald-700" />
                <span>সদস্য হওয়ার আবশ্যক শর্তাবলী</span>
              </h3>
              <ul className="text-xs sm:text-sm text-gray-600 space-y-2.5 list-disc pl-5">
                <li>আবেদনকারীকে অবশ্যই হাজারীবাগ থানার স্থায়ী বাসিন্দা অথবা থানায় অবস্থিত শিক্ষাপ্রতিষ্ঠানের শিক্ষার্থী হতে হবে।</li>
                <li>বাংলাদেশ ছাত্রলীগের আদর্শ ও উদ্দেশ্য এবং জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমানের আদর্শের অনুসারী হতে হবে।</li>
                <li>আবেদনকারীর বয়স অবশ্যই গঠনতান্ত্রিক বিধিমালার মধ্যে হতে হবে।</li>
                <li>কোনো ধরনের অসামাজিক বা শৃঙ্খলা বিরোধী কার্যকলাপে যুক্ত থাকা যাবে না।</li>
              </ul>
            </div>

          </div>

        </div>

        {/* ADMIN DATABASE DASHBOARD VIEW */}
        {isAdmin && (
          <div className="mt-16 pt-10 border-t-2 border-emerald-100 space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-emerald-100 shadow-sm space-y-6">
              
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-gray-100">
                <div className="flex items-center space-x-2">
                  <Inbox className="text-emerald-600" size={22} />
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 font-sans">অ্যাডমিন সাবমিশন ডাটাবেস</h3>
                    <p className="text-xs text-gray-400">নিবন্ধিত রক্তদাতা, নতুন সদস্য আবেদন এবং যোগাযোগ ফর্ম থেকে সংগৃহীত ডাটা সমূহ।</p>
                  </div>
                </div>

                {/* DB Tabs */}
                <div className="flex bg-slate-100 p-1 rounded-xl">
                  <button
                    onClick={() => setActiveAdminTab('donors')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeAdminTab === 'donors' ? 'bg-white text-emerald-800 shadow-xs' : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    রক্তদাতা তালিকা ({donorList.length})
                  </button>
                  <button
                    onClick={() => setActiveAdminTab('members')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeAdminTab === 'members' ? 'bg-white text-emerald-800 shadow-xs' : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    সদস্য আবেদনসমূহ ({memberApplications.length})
                  </button>
                  <button
                    onClick={() => setActiveAdminTab('messages')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeAdminTab === 'messages' ? 'bg-white text-emerald-800 shadow-xs' : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    যোগাযোগ বার্তা ({contactMessages.length})
                  </button>
                </div>
              </div>

              {/* TAB 1: Blood Donors list */}
              {activeAdminTab === 'donors' && (
                <div className="overflow-x-auto">
                  {donorList.length === 0 ? (
                    <p className="text-gray-400 text-center py-8 text-xs font-semibold">কোনো রক্তদাতার রেজিস্ট্রেশন ডাটা পাওয়া যায়নি।</p>
                  ) : (
                    <table className="min-w-full divide-y divide-gray-100 text-left text-xs md:text-sm">
                      <thead className="bg-slate-50 text-gray-500 font-bold uppercase tracking-wider text-[11px]">
                        <tr>
                          <th className="px-4 py-3">তারিখ</th>
                          <th className="px-4 py-3">নাম</th>
                          <th className="px-4 py-3 text-center">রক্তের গ্রুপ</th>
                          <th className="px-4 py-3">মোবাইল</th>
                          <th className="px-4 py-3">ঠিকানা</th>
                          <th className="px-4 py-3">মন্তব্য</th>
                          <th className="px-4 py-3 text-center">অ্যাকশন</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 bg-white text-slate-700">
                        {donorList.map((donor) => (
                          <tr key={donor.id} className="hover:bg-slate-50/50">
                            <td className="px-4 py-3 text-gray-400 font-mono whitespace-nowrap">{donor.date}</td>
                            <td className="px-4 py-3 font-bold text-slate-800">{donor.name}</td>
                            <td className="px-4 py-3 text-center">
                              <span className="bg-red-500 text-white font-bold px-2.5 py-1 rounded-md text-[11px] inline-block">{donor.bloodGroup}</span>
                            </td>
                            <td className="px-4 py-3 font-semibold text-emerald-700 font-mono">{donor.mobile}</td>
                            <td className="px-4 py-3 max-w-[150px] truncate">{donor.address}</td>
                            <td className="px-4 py-3 text-gray-400 max-w-[150px] truncate">{donor.comments || '-'}</td>
                            <td className="px-4 py-3 text-center whitespace-nowrap">
                              <button
                                onClick={() => deleteDonor(donor.id)}
                                className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                                title="মুছুন"
                              >
                                <Trash2 size={14} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* TAB 2: Member Applications list */}
              {activeAdminTab === 'members' && (
                <div className="overflow-x-auto">
                  {memberApplications.length === 0 ? (
                    <p className="text-gray-400 text-center py-8 text-xs font-semibold">কোনো সদস্য আবেদনপত্র পাওয়া যায়নি।</p>
                  ) : (
                    <table className="min-w-full divide-y divide-gray-100 text-left text-xs md:text-sm">
                      <thead className="bg-slate-50 text-gray-500 font-bold uppercase tracking-wider text-[11px]">
                        <tr>
                          <th className="px-4 py-3">তারিখ</th>
                          <th className="px-4 py-3">আবেদনকারী</th>
                          <th className="px-4 py-3">অভিভাবক</th>
                          <th className="px-4 py-3">প্রতিষ্ঠান ও ক্লাস</th>
                          <th className="px-4 py-3">মোবাইল / NID</th>
                          <th className="px-4 py-3 text-center">স্ট্যাটাস</th>
                          <th className="px-4 py-3 text-center">অ্যাকশন</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 bg-white text-slate-700">
                        {memberApplications.map((member) => (
                          <tr key={member.id} className="hover:bg-slate-50/50">
                            <td className="px-4 py-3 text-gray-400 font-mono whitespace-nowrap">{member.date}</td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div className="flex items-center space-x-2.5">
                                <img
                                  src={member.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=150&auto=format&fit=crop'}
                                  alt="Profile"
                                  className="w-8 h-8 rounded-full object-cover border border-gray-200"
                                />
                                <div>
                                  <div className="font-bold text-slate-800">{member.name}</div>
                                  <div className="text-[10px] text-gray-400 font-mono">{member.dob}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-4 py-3 max-w-[120px] truncate">{member.fatherMotherName}</td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div className="font-semibold text-slate-700">{member.institution || '-'}</div>
                              <div className="text-[10px] text-gray-400">{member.classYear || '-'}</div>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div className="font-semibold text-slate-700 font-mono">{member.mobile}</div>
                              <div className="text-[10px] text-gray-400 font-mono">NID: {member.nidBirthReg}</div>
                            </td>
                            <td className="px-4 py-3 text-center whitespace-nowrap">
                              <span
                                className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                  member.status === 'approved'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : member.status === 'rejected'
                                    ? 'bg-red-100 text-red-800'
                                    : 'bg-yellow-100 text-yellow-800'
                                }`}
                              >
                                {member.status === 'approved' ? 'অনুমোদিত' : member.status === 'rejected' ? 'বাতিল' : 'অপেক্ষমাণ'}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-center whitespace-nowrap">
                              <div className="flex items-center justify-center space-x-1.5">
                                <button
                                  onClick={() => updateMemberStatus(member.id, 'approved')}
                                  className="px-2 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-md text-[10px] font-bold"
                                >
                                  অনুমোদন
                                </button>
                                <button
                                  onClick={() => updateMemberStatus(member.id, 'rejected')}
                                  className="px-2 py-1 bg-red-50 text-red-700 hover:bg-red-100 rounded-md text-[10px] font-bold"
                                >
                                  বাতিল
                                </button>
                                <button
                                  onClick={() => deleteMember(member.id)}
                                  className="p-1 text-gray-400 hover:text-red-500 rounded-lg"
                                  title="মুছুন"
                                >
                                  <Trash2 size={13} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* TAB 3: Contact Messages list */}
              {activeAdminTab === 'messages' && (
                <div className="overflow-x-auto">
                  {contactMessages.length === 0 ? (
                    <p className="text-gray-400 text-center py-8 text-xs font-semibold">কোনো যোগাযোগ বার্তা পাওয়া যায়নি।</p>
                  ) : (
                    <table className="min-w-full divide-y divide-gray-100 text-left text-xs md:text-sm">
                      <thead className="bg-slate-50 text-gray-500 font-bold uppercase tracking-wider text-[11px]">
                        <tr>
                          <th className="px-4 py-3">তারিখ</th>
                          <th className="px-4 py-3">প্রেরক</th>
                          <th className="px-4 py-3">যোগাযোগ</th>
                          <th className="px-4 py-3">বার্তা</th>
                          <th className="px-4 py-3 text-center">অ্যাকশন</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 bg-white text-slate-700">
                        {contactMessages.map((msg) => (
                          <tr key={msg.id} className="hover:bg-slate-50/50">
                            <td className="px-4 py-3 text-gray-400 font-mono whitespace-nowrap">{msg.date}</td>
                            <td className="px-4 py-3 font-bold text-slate-800 whitespace-nowrap">{msg.name}</td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div className="font-semibold text-slate-700 font-mono">{msg.mobile}</div>
                              <div className="text-[10px] text-gray-400">{msg.email || '-'}</div>
                            </td>
                            <td className="px-4 py-3 max-w-[300px] whitespace-pre-wrap leading-relaxed">{msg.message}</td>
                            <td className="px-4 py-3 text-center whitespace-nowrap">
                              <button
                                onClick={() => deleteMessage(msg.id)}
                                className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                                title="মুছুন"
                              >
                                <Trash2 size={14} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

            </div>
          </div>
        )}

      </div>
    </section>
  );
}
