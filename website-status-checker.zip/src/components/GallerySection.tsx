/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Image, Video, Plus, Trash2, X, FolderPlus, FolderKanban, Edit3, Film } from 'lucide-react';
import { GalleryItem } from '../types';

interface GallerySectionProps {
  gallery: GalleryItem[];
  onUpdateGallery: (updatedGallery: GalleryItem[]) => void;
  customCategories: string[];
  onUpdateCategories: (updatedCategories: string[]) => void;
  isAdmin: boolean;
}

export default function GallerySection({
  gallery,
  onUpdateGallery,
  customCategories,
  onUpdateCategories,
  isAdmin,
}: GallerySectionProps) {
  const [activeCategory, setActiveCategory] = useState<string>('সকল');
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');

  // Item form states
  const [itemTitle, setItemTitle] = useState('');
  const [itemImg, setItemImg] = useState('');
  const [itemCat, setItemCat] = useState('রাজনৈতিক');
  const [itemType, setItemType] = useState<'image' | 'video'>('image');
  const [itemVideoUrl, setItemVideoUrl] = useState('');

  const addNewCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;
    const cleanName = newCategoryName.trim();
    if (customCategories.includes(cleanName)) {
      alert('এই গ্যালারি ফোল্ডারটি ইতিমধ্যেই রয়েছে!');
      return;
    }
    onUpdateCategories([...customCategories, cleanName]);
    setActiveCategory(cleanName);
    setNewCategoryName('');
    setIsAddingCategory(false);
  };

  const deleteCategory = (cat: string) => {
    if (cat === 'সকল') {
      alert('ডিফল্ট ফোল্ডার মোছা সম্ভব নয়!');
      return;
    }
    if (confirm(`আপনি কি নিশ্চিত যে "${cat}" ফোল্ডারটি মুছে ফেলতে চান? গ্যালারির সকল ফাইল "সকল" ফোল্ডারে থেকে যাবে।`)) {
      onUpdateCategories(customCategories.filter((c) => c !== cat));
      onUpdateGallery(
        gallery.map((item) => (item.category === cat ? { ...item, category: 'রাজনৈতিক' } : item))
      );
      setActiveCategory('সকল');
    }
  };

  const addNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemTitle.trim() || !itemImg.trim()) return;

    const newItem: GalleryItem = {
      id: `gallery-${Date.now()}`,
      title: itemTitle,
      imageUrl: itemImg,
      category: itemCat,
      type: itemType,
      videoUrl: itemType === 'video' ? itemVideoUrl : undefined,
    };

    onUpdateGallery([...gallery, newItem]);
    setIsAddingItem(false);
    setItemTitle('');
    setItemImg('');
    setItemVideoUrl('');
  };

  const deleteItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('আপনি কি নিশ্চিত যে এই গ্যালারি আইটেমটি মুছে ফেলতে চান?')) {
      onUpdateGallery(gallery.filter((item) => item.id !== id));
    }
  };

  const filteredItems =
    activeCategory === 'সকল'
      ? gallery
      : gallery.filter((item) => item.category === activeCategory);

  return (
    <section id="gallery" className="py-16 bg-slate-50 border-b border-emerald-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto mb-12">
          <span className="text-emerald-700 font-bold text-sm tracking-widest uppercase bg-emerald-100 px-3 py-1 rounded-full">
            মিডিয়া ও গ্যালারি
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-3 font-sans">
            ছবি ও ভিডিও গ্যালারি
          </h2>
          <p className="text-gray-500 mt-2 text-sm sm:text-base">
            হাজারীবাগ থানা ছাত্রলীগের ঐতিহাসিক বিভিন্ন কর্মসূচির আকর্ষণীয় স্থিরচিত্র ও ভিডিওসমূহ।
          </p>
        </div>

        {/* Gallery Folder/Tabs bar */}
        <div className="flex flex-wrap justify-center items-center gap-2 mb-10 bg-white p-2.5 rounded-2xl shadow-xs border border-emerald-50 max-w-4xl mx-auto">
          {customCategories.map((cat) => (
            <div key={cat} className="relative group">
              <button
                onClick={() => setActiveCategory(cat)}
                className={`flex items-center space-x-1.5 px-4.5 py-2.5 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-emerald-700 hover:bg-emerald-50'
                }`}
              >
                <FolderKanban size={15} />
                <span>{cat}</span>
              </button>

              {isAdmin && cat !== 'সকল' && (
                <button
                  onClick={() => deleteCategory(cat)}
                  className="absolute -top-1.5 -right-1.5 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
                  title="ফোল্ডারটি মুছুন"
                >
                  <X size={10} />
                </button>
              )}
            </div>
          ))}

          {isAdmin && (
            <button
              onClick={() => setIsAddingCategory(true)}
              className="flex items-center space-x-1 px-4 py-2.5 bg-sky-50 text-sky-700 rounded-xl text-sm font-bold border border-dashed border-sky-300 hover:bg-sky-100 transition-colors"
            >
              <FolderPlus size={16} />
              <span>নতুন ফোল্ডার</span>
            </button>
          )}
        </div>

        {/* Actions Button for adding photo/video */}
        {isAdmin && (
          <div className="mb-8 flex justify-center">
            <button
              onClick={() => setIsAddingItem(true)}
              className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-2.5 rounded-xl text-sm shadow-md transition-transform transform active:scale-95"
            >
              <Plus size={16} />
              <span>গ্যালারিতে নতুন ফাইল যোগ করুন</span>
            </button>
          </div>
        )}

        {/* Gallery Grid */}
        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-2xl py-12 px-6 border border-dashed border-gray-300 text-gray-500 max-w-xl mx-auto">
            <Image size={48} className="mx-auto text-emerald-200 mb-3" />
            <p className="text-base font-semibold">এই ফোল্ডারে কোনো ছবি বা ভিডিও নেই।</p>
            {isAdmin && <p className="text-xs text-gray-400 mt-1">উপরে "ফাইল যোগ করুন" বোতামে চাপ দিয়ে নতুন মিডিয়া আপলোড করুন।</p>}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="group relative bg-white rounded-2xl overflow-hidden shadow-xs border border-emerald-50 hover:border-emerald-600 hover:shadow-md transition-all duration-300 h-64 flex flex-col justify-end cursor-pointer"
              >
                {/* Image background */}
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />

                {/* Dark gradient mask */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent opacity-80" />

                {/* Content Overlay */}
                <div className="relative z-10 p-4 text-left space-y-1.5">
                  <span className="inline-block bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider">
                    {item.category}
                  </span>
                  <h3 className="text-sm font-bold text-white font-sans drop-shadow-md leading-snug line-clamp-2">
                    {item.title}
                  </h3>
                </div>

                {/* Video Play Icon overlay if type is video */}
                {item.type === 'video' && (
                  <div className="absolute inset-0 flex items-center justify-center z-10 text-white/90 group-hover:text-red-500 transition-colors">
                    <div className="bg-black/50 p-3 rounded-full backdrop-blur-xs group-hover:scale-110 transition-transform">
                      <Film size={24} />
                    </div>
                  </div>
                )}

                {/* Open video URL option */}
                {item.type === 'video' && item.videoUrl && (
                  <a
                    href={item.videoUrl}
                    target="_blank"
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 z-20"
                    title="ভিডিও লিংক দেখুন"
                  />
                )}

                {/* Admin controls */}
                {isAdmin && (
                  <div className="absolute top-3 right-3 z-30 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => deleteItem(item.id, e)}
                      className="p-1.5 bg-red-600 text-white rounded-full hover:bg-red-700 shadow-md"
                      title="মুছুন"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Add Category Dialog */}
        {isAddingCategory && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-emerald-100 animate-in fade-in zoom-in-95 duration-150 text-left">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <FolderPlus size={18} className="text-emerald-600" />
                  নতুন গ্যালারি ফোল্ডার তৈরি
                </h3>
                <button
                  onClick={() => setIsAddingCategory(false)}
                  className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100"
                >
                  <X size={18} />
                </button>
              </div>
              <form onSubmit={addNewCategory} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                    ফোল্ডারের নাম (যেমন: "শোক দিবস", "ক্রীড়া প্রতিযোগিতা")
                  </label>
                  <input
                    type="text"
                    required
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                    placeholder="যেমন: খেলাধুলা ও সংস্কৃতি"
                  />
                </div>
                <div className="flex space-x-3 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingCategory(false)}
                    className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-sm font-medium hover:bg-emerald-700 shadow-md"
                  >
                    তৈরি করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Add Item Dialog */}
        {isAddingItem && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-emerald-100 animate-in fade-in zoom-in-95 duration-150 text-left">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <Image size={18} className="text-emerald-600" />
                  গ্যালারিতে ফাইল যোগ করুন
                </h3>
                <button
                  onClick={() => setIsAddingItem(false)}
                  className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100"
                >
                  <X size={18} />
                </button>
              </div>

              <form onSubmit={addNewItem} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    ফাইলের ক্যাপশন / টাইটেল
                  </label>
                  <input
                    type="text"
                    required
                    value={itemTitle}
                    onChange={(e) => setItemTitle(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                    placeholder="ফাইলের আকর্ষণীয় ক্যাপশন"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                      মিডিয়া টাইপ
                    </label>
                    <select
                      value={itemType}
                      onChange={(e) => setItemType(e.target.value as 'image' | 'video')}
                      className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm bg-white cursor-pointer"
                    >
                      <option value="image">ছবি (Photo)</option>
                      <option value="video">ভিডিও (Video)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                      ক্যাটাগরি ফোল্ডার
                    </label>
                    <select
                      value={itemCat}
                      onChange={(e) => setItemCat(e.target.value)}
                      className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm bg-white cursor-pointer"
                    >
                      {customCategories.filter((c) => c !== 'সকল').map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    ছবি ছবির লিঙ্ক (Image URL)
                  </label>
                  <input
                    type="text"
                    required
                    value={itemImg}
                    onChange={(e) => setItemImg(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm font-mono"
                    placeholder="https://images.unsplash.com/..."
                  />
                </div>

                {itemType === 'video' && (
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                      ভিডিও লিঙ্ক (যেমন: YouTube/Facebook Video Link)
                    </label>
                    <input
                      type="text"
                      required
                      value={itemVideoUrl}
                      onChange={(e) => setItemVideoUrl(e.target.value)}
                      className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm font-mono"
                      placeholder="https://youtube.com/watch?v=..."
                    />
                  </div>
                )}

                {itemImg && (
                  <div className="p-2.5 bg-gray-50 rounded-xl border border-dashed border-gray-200 flex flex-col items-center">
                    <span className="text-[10px] text-gray-400 mb-2">মিডিয়া প্রিভিউ</span>
                    <img
                      src={itemImg}
                      alt="Preview"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?q=80&w=600&auto=format&fit=crop';
                      }}
                      className="w-full h-28 object-cover rounded-lg shadow-sm"
                    />
                  </div>
                )}

                <div className="flex space-x-3 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingItem(false)}
                    className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-sm font-medium hover:bg-emerald-700 shadow-md"
                  >
                    সংরক্ষণ করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
