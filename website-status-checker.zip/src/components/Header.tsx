/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Menu, X, Shield, Lock, Unlock, Settings } from 'lucide-react';
import { WebsiteConfig } from '../types';

interface HeaderProps {
  config: WebsiteConfig;
  onEditConfig: (updatedConfig: Partial<WebsiteConfig>) => void;
  isAdmin: boolean;
  setIsAdmin: (isAdmin: boolean) => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export default function Header({
  config,
  onEditConfig,
  isAdmin,
  setIsAdmin,
  activeSection,
  setActiveSection,
}: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isEditingLogo, setIsEditingLogo] = useState(false);
  const [logoInput, setLogoInput] = useState(config.logoUrl);

  const navigationItems = [
    { id: 'home', label: 'হোম' },
    { id: 'about', label: 'আমাদের সম্পর্কে' },
    { id: 'committee', label: 'কমিটি ও নেতৃত্ব' },
    { id: 'notices', label: 'নোটিশ ও খবর' },
    { id: 'donor-form', label: 'রক্তদাতা কর্নার' },
    { id: 'member-form', label: 'সদস্য আবেদন' },
    { id: 'gallery', label: 'গ্যালারি' },
    { id: 'contact', label: 'যোগাযোগ' },
  ];

  const handleLogoSave = (e: React.FormEvent) => {
    e.preventDefault();
    onEditConfig({ logoUrl: logoInput });
    setIsEditingLogo(false);
  };

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md shadow-sm border-b border-emerald-100">
      {/* Top green/red flag stripe */}
      <div className="h-1.5 w-full flex">
        <div className="bg-emerald-600 h-full w-[70%]" />
        <div className="bg-red-600 h-full w-[30%]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Logo and Brand Name */}
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="relative group">
              <img
                src={config.logoUrl || 'https://images.unsplash.com/photo-1621640100414-03a0368c8536?q=80&w=200&auto=format&fit=crop'}
                alt="BCL Logo"
                className="w-12 h-12 rounded-full border-2 border-emerald-600 object-cover cursor-pointer hover:brightness-90 transition-all shadow-inner"
                onClick={() => isAdmin && setIsEditingLogo(true)}
              />
              {isAdmin && (
                <div 
                  className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full text-white text-[10px] font-bold opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity"
                  onClick={() => setIsEditingLogo(true)}
                >
                  পরিবর্তন
                </div>
              )}
            </div>

            <div>
              <h1 className="text-emerald-800 font-bold text-lg md:text-xl tracking-tight font-sans">
                {config.bannerTitle}
              </h1>
              <p className="text-gray-500 text-xs md:text-sm font-medium">
                {config.bannerSubtitle}
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`px-3 py-2 rounded-lg text-[15px] font-medium transition-all ${
                  activeSection === item.id
                    ? 'bg-emerald-50 text-emerald-700 shadow-sm border border-emerald-100/50'
                    : 'text-gray-600 hover:text-emerald-600 hover:bg-emerald-50/50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right Side: Admin toggle + Mobile menu button */}
          <div className="flex items-center space-x-3">
            {/* Admin Toggle Button */}
            <button
              onClick={() => setIsAdmin(!isAdmin)}
              className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all shadow-sm ${
                isAdmin
                  ? 'bg-red-500 text-white hover:bg-red-600 pulse-glow'
                  : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
              }`}
            >
              {isAdmin ? (
                <>
                  <Unlock size={14} />
                  <span>সম্পাদনা অন</span>
                </>
              ) : (
                <>
                  <Lock size={14} />
                  <span>সম্পাদনা করুন</span>
                </>
              )}
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Panel */}
      {isMenuOpen && (
        <div className="lg:hidden border-t border-emerald-100 bg-white/98 backdrop-blur-md">
          <div className="px-4 pt-2 pb-6 space-y-1 sm:px-3">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`block w-full text-left px-4 py-3 rounded-lg text-base font-medium transition-all ${
                  activeSection === item.id
                    ? 'bg-emerald-50 text-emerald-700 font-bold border-l-4 border-emerald-600'
                    : 'text-gray-600 hover:text-emerald-600 hover:bg-emerald-50/50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Admin Mode Banner */}
      {isAdmin && (
        <div className="bg-red-50 text-red-800 text-xs py-1.5 px-4 text-center border-b border-red-200 font-medium animate-pulse flex items-center justify-center space-x-2">
          <Shield size={14} className="text-red-500" />
          <span>সম্পাদনা মোড সক্রিয়! যেকোনো লেখা বা ছবিতে ক্লিক করে বা এডিট বাটনে চাপ দিয়ে সরাসরি ওয়েবসাইট পরিবর্তন করুন।</span>
        </div>
      )}

      {/* Logo Editing Modal */}
      {isEditingLogo && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-emerald-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                <Settings size={18} className="text-emerald-600" />
                লোগো পরিবর্তন করুন
              </h3>
              <button
                onClick={() => setIsEditingLogo(false)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100"
              >
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleLogoSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                  লোগো ছবির লিঙ্ক (Image URL / Base64)
                </label>
                <input
                  type="text"
                  required
                  value={logoInput}
                  onChange={(e) => setLogoInput(e.target.value)}
                  className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all text-sm font-mono"
                  placeholder="https://example.com/logo.png"
                />
              </div>

              {logoInput && (
                <div className="flex flex-col items-center justify-center p-3 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                  <span className="text-[11px] text-gray-400 mb-2">লোগো প্রিভিউ</span>
                  <img
                    src={logoInput}
                    alt="Logo Preview"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1621640100414-03a0368c8536?q=80&w=200&auto=format&fit=crop';
                    }}
                    className="w-20 h-20 rounded-full border border-gray-300 object-cover shadow-sm"
                  />
                </div>
              )}

              <div className="flex space-x-3 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditingLogo(false)}
                  className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors shadow-md"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </header>
  );
}
