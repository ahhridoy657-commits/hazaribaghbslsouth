/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Edit3, X, Camera, Plus, Trash2 } from 'lucide-react';
import { Slide } from '../types';

interface HeroSliderProps {
  slides: Slide[];
  onUpdateSlides: (updatedSlides: Slide[]) => void;
  isAdmin: boolean;
}

export default function HeroSlider({ slides, onUpdateSlides, isAdmin }: HeroSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [editingSlide, setEditingSlide] = useState<Slide | null>(null);
  const [slideImageInput, setSlideImageInput] = useState('');
  const [slideTitleInput, setSlideTitleInput] = useState('');
  const [slideNameInput, setSlideNameInput] = useState('');
  const [slideDesigInput, setSlideDesigInput] = useState('');

  // Auto rotate slides
  useEffect(() => {
    if (isAdmin) return; // Pause auto-rotate when in admin mode for easier editing
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [slides.length, isAdmin]);

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? slides.length - 1 : prevIndex - 1));
  };

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
  };

  const openEditModal = (slide: Slide) => {
    setEditingSlide(slide);
    setSlideImageInput(slide.imageUrl);
    setSlideTitleInput(slide.title);
    setSlideNameInput(slide.name);
    setSlideDesigInput(slide.designation);
  };

  const saveSlideChanges = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSlide) return;

    const updated = slides.map((s) =>
      s.id === editingSlide.id
        ? {
            ...s,
            imageUrl: slideImageInput,
            title: slideTitleInput,
            name: slideNameInput,
            designation: slideDesigInput,
          }
        : s
    );
    onUpdateSlides(updated);
    setEditingSlide(null);
  };

  const addNewSlide = () => {
    const newId = `slide-${Date.now()}`;
    const newS: Slide = {
      id: newId,
      imageUrl: 'https://images.unsplash.com/photo-1599074914978-2946b69e5740?q=80&w=1200&auto=format&fit=crop',
      title: 'নতুন স্লাইডার টাইটেল',
      name: 'শুভেচ্ছা বার্তা',
      designation: 'পদবি বা বিস্তারিত বিবরণ এখানে লিখুন'
    };
    onUpdateSlides([...slides, newS]);
    setCurrentIndex(slides.length); // switch to the new slide
  };

  const deleteSlide = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (slides.length <= 1) {
      alert('কমপক্ষে একটি স্লাইড অবশ্যই থাকতে হবে!');
      return;
    }
    if (confirm('আপনি কি নিশ্চিত যে এই স্লাইডটি মুছে ফেলতে চান?')) {
      const filtered = slides.filter((s) => s.id !== id);
      onUpdateSlides(filtered);
      setCurrentIndex(0);
    }
  };

  const currentSlide = slides[currentIndex] || slides[0];

  if (!currentSlide) return null;

  return (
    <section id="home" className="relative h-[460px] md:h-[580px] w-full overflow-hidden bg-slate-900 select-none">
      {/* Background Image / Slider Content */}
      <div className="absolute inset-0 transition-all duration-1000 ease-in-out">
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-transparent z-10" />
        <img
          src={currentSlide.imageUrl}
          alt={currentSlide.title}
          className="h-full w-full object-cover transform scale-102 transition-transform duration-10000 ease-out"
        />
      </div>

      {/* Floating texts */}
      <div className="absolute inset-0 z-20 flex flex-col justify-end pb-16 md:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="max-w-3xl space-y-4 animate-in fade-in slide-in-from-bottom-6 duration-700">
          <span className="inline-block bg-red-600/90 text-white text-xs md:text-sm font-bold px-3.5 py-1.5 rounded-full uppercase tracking-wider shadow-md">
            {currentSlide.title}
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white leading-tight font-sans drop-shadow-md">
            {currentSlide.name}
          </h2>
          <p className="text-gray-200 text-sm md:text-lg font-medium max-w-2xl leading-relaxed drop-shadow-xs">
            {currentSlide.designation}
          </p>
        </div>
      </div>

      {/* Navigation Controls */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 p-2.5 rounded-full bg-black/40 text-white/80 hover:bg-emerald-600 hover:text-white transition-all shadow-md backdrop-blur-xs"
        aria-label="Previous slide"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 p-2.5 rounded-full bg-black/40 text-white/80 hover:bg-emerald-600 hover:text-white transition-all shadow-md backdrop-blur-xs"
        aria-label="Next slide"
      >
        <ChevronRight size={24} />
      </button>

      {/* Dots Indicator & Admin controls */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center space-y-3">
        {/* Indicators */}
        <div className="flex space-x-2">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`h-2.5 rounded-full transition-all duration-300 ${
                idx === currentIndex ? 'w-8 bg-emerald-500' : 'w-2.5 bg-white/40 hover:bg-white/70'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>

        {/* Add/Edit/Delete Overlay for Admins */}
        {isAdmin && (
          <div className="flex items-center space-x-2 bg-black/70 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/10 shadow-lg">
            <button
              onClick={() => openEditModal(currentSlide)}
              className="flex items-center space-x-1 text-xs text-emerald-400 hover:text-emerald-300 font-bold px-2 py-1 rounded transition-colors"
            >
              <Edit3 size={12} />
              <span>এডিট করুন</span>
            </button>
            <span className="text-white/30">|</span>
            <button
              onClick={addNewSlide}
              className="flex items-center space-x-1 text-xs text-sky-400 hover:text-sky-300 font-bold px-2 py-1 rounded transition-colors"
            >
              <Plus size={12} />
              <span>নতুন যোগ করুন</span>
            </button>
            <span className="text-white/30">|</span>
            <button
              onClick={(e) => deleteSlide(currentSlide.id, e)}
              className="flex items-center space-x-1 text-xs text-red-400 hover:text-red-300 font-bold px-2 py-1 rounded transition-colors"
            >
              <Trash2 size={12} />
              <span>মুছুন</span>
            </button>
          </div>
        )}
      </div>

      {/* Slide Editing Modal */}
      {editingSlide && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-emerald-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                <Edit3 size={18} className="text-emerald-600" />
                স্লাইডার তথ্য সম্পাদনা
              </h3>
              <button
                onClick={() => setEditingSlide(null)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100"
              >
                <X size={18} />
              </button>
            </div>
            
            <form onSubmit={saveSlideChanges} className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                  ছোট লাল ব্যাজ লেখা (যেমন: "ঐতিহাসিক হাজারীবাগ থানা ছাত্রলীগ")
                </label>
                <input
                  type="text"
                  required
                  value={slideTitleInput}
                  onChange={(e) => setSlideTitleInput(e.target.value)}
                  className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                  প্রধান বড় লেখা (নাম / শিরোনাম)
                </label>
                <input
                  type="text"
                  required
                  value={slideNameInput}
                  onChange={(e) => setSlideNameInput(e.target.value)}
                  className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                  নিচের বিস্তারিত বার্তা (পদবি / স্লোগান)
                </label>
                <textarea
                  rows={2}
                  required
                  value={slideDesigInput}
                  onChange={(e) => setSlideDesigInput(e.target.value)}
                  className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                  স্লাইডের ব্যাকগ্রাউন্ড ছবি (Image URL)
                </label>
                <input
                  type="text"
                  required
                  value={slideImageInput}
                  onChange={(e) => setSlideImageInput(e.target.value)}
                  className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm font-mono"
                  placeholder="https://images.unsplash.com/..."
                />
              </div>

              {slideImageInput && (
                <div className="p-3 bg-gray-50 rounded-xl border border-dashed border-gray-200 flex flex-col items-center">
                  <span className="text-[11px] text-gray-400 mb-2">ব্যাকগ্রাউন্ড ছবি প্রিভিউ</span>
                  <img
                    src={slideImageInput}
                    alt="Slide Preview"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1599074914978-2946b69e5740?q=80&w=1200&auto=format&fit=crop';
                    }}
                    className="w-full h-32 object-cover rounded-lg shadow-inner border border-gray-200"
                  />
                </div>
              )}

              <div className="flex space-x-3 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setEditingSlide(null)}
                  className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors shadow-md"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
}
