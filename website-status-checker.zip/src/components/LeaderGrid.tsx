/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Edit3, Trash2, X, Phone, Mail, FolderPlus, FolderKanban } from 'lucide-react';
import { Leader } from '../types';

interface LeaderGridProps {
  leaders: Leader[];
  onUpdateLeaders: (updatedLeaders: Leader[]) => void;
  customCategories: string[];
  onUpdateCategories: (updatedCategories: string[]) => void;
  isAdmin: boolean;
}

export default function LeaderGrid({
  leaders,
  onUpdateLeaders,
  customCategories,
  onUpdateCategories,
  isAdmin,
}: LeaderGridProps) {
  const [activeCategory, setActiveCategory] = useState<string>('dhaka-south');
  const [editingLeader, setEditingLeader] = useState<Leader | null>(null);
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');

  // Form states for leaders
  const [leaderName, setLeaderName] = useState('');
  const [leaderDesig, setLeaderDesig] = useState('');
  const [leaderImg, setLeaderImg] = useState('');
  const [leaderPhone, setLeaderPhone] = useState('');
  const [leaderEmail, setLeaderEmail] = useState('');
  const [leaderCat, setLeaderCat] = useState('');

  const categoryLabels: Record<string, string> = {
    'dhaka-south': 'ঢাকা মহানগর দক্ষিণ',
    'thana': 'হাজারীবাগ থানা কমিটি',
    'ward-14': '১৪ নং ওয়ার্ড ছাত্রলীগ',
    'ward-22': '২২ নং ওয়ার্ড ছাত্রলীগ',
  };

  const getCategoryLabel = (cat: string) => {
    return categoryLabels[cat] || cat;
  };

  const openAddLeaderModal = () => {
    setEditingLeader({
      id: `leader-${Date.now()}`,
      name: '',
      designation: '',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop',
      phone: '',
      email: '',
      category: activeCategory,
    });
    setLeaderName('');
    setLeaderDesig('');
    setLeaderImg('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop');
    setLeaderPhone('');
    setLeaderEmail('');
    setLeaderCat(activeCategory);
  };

  const openEditLeaderModal = (leader: Leader) => {
    setEditingLeader(leader);
    setLeaderName(leader.name);
    setLeaderDesig(leader.designation);
    setLeaderImg(leader.imageUrl);
    setLeaderPhone(leader.phone || '');
    setLeaderEmail(leader.email || '');
    setLeaderCat(leader.category);
  };

  const saveLeader = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLeader) return;

    const newLeaderData: Leader = {
      id: editingLeader.id,
      name: leaderName,
      designation: leaderDesig,
      imageUrl: leaderImg,
      phone: leaderPhone || undefined,
      email: leaderEmail || undefined,
      category: leaderCat,
    };

    const exists = leaders.some((l) => l.id === editingLeader.id);
    if (exists) {
      onUpdateLeaders(leaders.map((l) => (l.id === editingLeader.id ? newLeaderData : l)));
    } else {
      onUpdateLeaders([...leaders, newLeaderData]);
    }
    setEditingLeader(null);
  };

  const deleteLeader = (id: string) => {
    if (confirm('আপনি কি নিশ্চিত যে এই নেতার কার্ডটি মুছে ফেলতে চান?')) {
      onUpdateLeaders(leaders.filter((l) => l.id !== id));
    }
  };

  const addNewCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;
    const cleanName = newCategoryName.trim();
    if (customCategories.includes(cleanName)) {
      alert('এই ক্যাটাগরি ফোল্ডারটি ইতিমধ্যেই রয়েছে!');
      return;
    }
    onUpdateCategories([...customCategories, cleanName]);
    setActiveCategory(cleanName);
    setNewCategoryName('');
    setIsAddingCategory(false);
  };

  const deleteCategory = (cat: string) => {
    if (['dhaka-south', 'thana', 'ward-14', 'ward-22'].includes(cat)) {
      alert('সিস্টেমের ডিফল্ট ফোল্ডার মোছা সম্ভব নয়!');
      return;
    }
    if (confirm(`আপনি কি নিশ্চিত যে "${cat}" ফোল্ডারটি মুছে ফেলতে চান? এর ভেতরের সকল নেতা থানা ক্যাটাগরিতে স্থানান্তরিত হবে।`)) {
      const updatedCategories = customCategories.filter((c) => c !== cat);
      onUpdateCategories(updatedCategories);
      onUpdateLeaders(
        leaders.map((l) => (l.category === cat ? { ...l, category: 'thana' } : l))
      );
      setActiveCategory('thana');
    }
  };

  const filteredLeaders = leaders.filter((l) => l.category === activeCategory);

  // Separate Dhaka South for special display layout
  const isDhakaSouthActive = activeCategory === 'dhaka-south';

  return (
    <section id="committee" className="py-16 bg-slate-50 border-b border-emerald-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        
        {/* Section Title */}
        <div className="max-w-3xl mx-auto mb-12">
          <span className="text-emerald-700 font-bold text-sm tracking-widest uppercase bg-emerald-100 px-3 py-1 rounded-full">
            নেতৃত্ব ও সংগঠন
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-3 font-sans">
            কমিটি এবং দায়িত্বপ্রাপ্ত নেতৃবৃন্দ
          </h2>
          <p className="text-gray-500 mt-2 text-sm sm:text-base">
            বাংলাদেশ ছাত্রলীগ, হাজারীবাগ থানা এবং ঢাকা মহানগর দক্ষিণের দায়িত্বপ্রাপ্ত সংগ্রামী ও বিপ্লবী নেতৃত্ব।
          </p>
        </div>

        {/* Directory Folder Navigation bar */}
        <div className="flex flex-wrap justify-center items-center gap-2 mb-10 bg-white p-2.5 rounded-2xl shadow-xs border border-emerald-50 max-w-5xl mx-auto">
          {customCategories.map((cat) => (
            <div key={cat} className="relative group">
              <button
                onClick={() => setActiveCategory(cat)}
                className={`flex items-center space-x-1.5 px-4.5 py-2.5 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-emerald-700 hover:bg-emerald-50'
                }`}
              >
                <FolderKanban size={15} />
                <span>{getCategoryLabel(cat)}</span>
              </button>
              
              {/* Delete custom folder icon for admin */}
              {isAdmin && !['dhaka-south', 'thana', 'ward-14', 'ward-22'].includes(cat) && (
                <button
                  onClick={() => deleteCategory(cat)}
                  className="absolute -top-1.5 -right-1.5 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
                  title="ফোল্ডারটি মুছুন"
                >
                  <X size={10} />
                </button>
              )}
            </div>
          ))}

          {/* Add Category Folder button */}
          {isAdmin && (
            <button
              onClick={() => setIsAddingCategory(true)}
              className="flex items-center space-x-1 px-4 py-2.5 bg-sky-50 text-sky-700 rounded-xl text-sm font-bold border border-dashed border-sky-300 hover:bg-sky-100 transition-colors"
            >
              <FolderPlus size={16} />
              <span>নতুন ফোল্ডার</span>
            </button>
          )}
        </div>

        {/* Action Button for adding leaders */}
        {isAdmin && (
          <div className="mb-8 flex justify-center">
            <button
              onClick={openAddLeaderModal}
              className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-2.5 rounded-xl text-sm shadow-md transition-transform transform active:scale-95"
            >
              <Plus size={16} />
              <span>{getCategoryLabel(activeCategory)}-এ নতুন নেতা যোগ করুন</span>
            </button>
          </div>
        )}

        {/* Leaders Display Grid */}
        {filteredLeaders.length === 0 ? (
          <div className="bg-white rounded-2xl py-12 px-6 border border-dashed border-gray-300 text-gray-500 max-w-xl mx-auto">
            <FolderKanban size={48} className="mx-auto text-emerald-200 mb-3" />
            <p className="text-base font-semibold">এই ফোল্ডারে এখনো কোনো নেতা যুক্ত করা হয়নি।</p>
            {isAdmin && <p className="text-xs text-gray-400 mt-1">উপরে "নতুন নেতা যোগ করুন" বোতামে চাপ দিয়ে কার্ড তৈরি করুন।</p>}
          </div>
        ) : isDhakaSouthActive ? (
          /* Premium Side-By-Side display for Mahanagar Leaders */
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto justify-center">
            {filteredLeaders.map((leader) => (
              <div
                key={leader.id}
                className="group relative bg-white rounded-3xl overflow-hidden shadow-md border-2 border-emerald-600/30 hover:border-emerald-600 transition-all duration-300 transform hover:-translate-y-1.5 flex flex-col items-center p-6 text-center"
              >
                {/* Image Frame */}
                <div className="relative w-44 h-44 rounded-full overflow-hidden border-4 border-red-500/10 group-hover:border-emerald-600/20 transition-all mb-4">
                  <img
                    src={leader.imageUrl}
                    alt={leader.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>

                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-slate-800 font-sans group-hover:text-emerald-700 transition-colors">
                    {leader.name}
                  </h3>
                  <p className="text-emerald-700 text-sm font-bold bg-emerald-50 px-3 py-1 rounded-full inline-block">
                    {leader.designation}
                  </p>
                  
                  {/* Contact details */}
                  {(leader.phone || leader.email) && (
                    <div className="flex flex-wrap justify-center gap-3 pt-3 text-xs text-gray-500">
                      {leader.phone && (
                        <a href={`tel:${leader.phone}`} className="flex items-center gap-1 hover:text-emerald-600">
                          <Phone size={12} />
                          <span>{leader.phone}</span>
                        </a>
                      )}
                      {leader.email && (
                        <a href={`mailto:${leader.email}`} className="flex items-center gap-1 hover:text-emerald-600">
                          <Mail size={12} />
                          <span>{leader.email}</span>
                        </a>
                      )}
                    </div>
                  )}
                </div>

                {/* Admin controls */}
                {isAdmin && (
                  <div className="absolute top-4 right-4 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEditLeaderModal(leader)}
                      className="p-2 bg-emerald-100 text-emerald-800 rounded-full hover:bg-emerald-200 shadow-sm"
                      title="সম্পাদনা"
                    >
                      <Edit3 size={12} />
                    </button>
                    <button
                      onClick={() => deleteLeader(leader.id)}
                      className="p-2 bg-red-100 text-red-800 rounded-full hover:bg-red-200 shadow-sm"
                      title="মুছুন"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          /* Normal responsive grid for other folders */
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {filteredLeaders.map((leader) => (
              <div
                key={leader.id}
                className="group relative bg-white rounded-2xl overflow-hidden shadow-sm border border-emerald-100 hover:border-emerald-600 hover:shadow-md transition-all duration-300 flex flex-col items-center p-5"
              >
                {/* Image Frame */}
                <div className="relative w-32 h-32 rounded-full overflow-hidden border-2 border-emerald-100 mb-4">
                  <img
                    src={leader.imageUrl}
                    alt={leader.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>

                <div className="text-center space-y-1.5 w-full">
                  <h3 className="text-base font-bold text-slate-800 font-sans group-hover:text-emerald-700 transition-colors truncate">
                    {leader.name}
                  </h3>
                  <p className="text-gray-500 text-xs font-semibold px-2 py-0.5 bg-gray-100 rounded-md inline-block max-w-full truncate">
                    {leader.designation}
                  </p>

                  {/* Contact details */}
                  {(leader.phone || leader.email) && (
                    <div className="flex flex-col items-center gap-1.5 pt-2.5 text-[11px] text-gray-400 border-t border-gray-50 w-full">
                      {leader.phone && (
                        <a href={`tel:${leader.phone}`} className="flex items-center gap-1 hover:text-emerald-600 justify-center">
                          <Phone size={10} />
                          <span>{leader.phone}</span>
                        </a>
                      )}
                      {leader.email && (
                        <a href={`mailto:${leader.email}`} className="flex items-center gap-1 hover:text-emerald-600 justify-center truncate max-w-full">
                          <Mail size={10} />
                          <span className="truncate">{leader.email}</span>
                        </a>
                      )}
                    </div>
                  )}
                </div>

                {/* Admin controls */}
                {isAdmin && (
                  <div className="absolute top-3 right-3 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEditLeaderModal(leader)}
                      className="p-1.5 bg-emerald-50 text-emerald-800 rounded-full hover:bg-emerald-100 shadow-xs"
                      title="সম্পাদনা"
                    >
                      <Edit3 size={11} />
                    </button>
                    <button
                      onClick={() => deleteLeader(leader.id)}
                      className="p-1.5 bg-red-50 text-red-800 rounded-full hover:bg-red-100 shadow-xs"
                      title="মুছুন"
                    >
                      <Trash2 size={11} />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Add Category Dialog */}
        {isAddingCategory && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-emerald-100 animate-in fade-in zoom-in-95 duration-150 text-left">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <FolderPlus size={18} className="text-emerald-600" />
                  নতুন কমিটি ফোল্ডার তৈরি
                </h3>
                <button
                  onClick={() => setIsAddingCategory(false)}
                  className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100"
                >
                  <X size={18} />
                </button>
              </div>
              <form onSubmit={addNewCategory} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                    ফোল্ডারের নাম (যেমন: "ওয়ার্ড ২২ কমিটি", "কেন্দ্রীয় নেতৃবৃন্দ")
                  </label>
                  <input
                    type="text"
                    required
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                    placeholder="যেমন: ওয়ার্ড ২২ কমিটি"
                  />
                </div>
                <div className="flex space-x-3 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setIsAddingCategory(false)}
                    className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-sm font-medium hover:bg-emerald-700 shadow-md"
                  >
                    তৈরি করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Leader Add/Edit Modal */}
        {editingLeader && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-emerald-100 animate-in fade-in zoom-in-95 duration-150 text-left">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <Edit3 size={18} className="text-emerald-600" />
                  নেতৃত্বের তথ্য পরিবর্তন
                </h3>
                <button
                  onClick={() => setEditingLeader(null)}
                  className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100"
                >
                  <X size={18} />
                </button>
              </div>

              <form onSubmit={saveLeader} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    নেতার পূর্ণ নাম
                  </label>
                  <input
                    type="text"
                    required
                    value={leaderName}
                    onChange={(e) => setLeaderName(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                    placeholder="যেমন: মোঃ রিফাত হাসান"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    পদবি / পদমর্যাদা
                  </label>
                  <input
                    type="text"
                    required
                    value={leaderDesig}
                    onChange={(e) => setLeaderDesig(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                    placeholder="যেমন: সাধারণ সম্পাদক, হাজারীবাগ থানা ছাত্রলীগ"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                      মোবাইল নম্বর (ঐচ্ছিক)
                    </label>
                    <input
                      type="text"
                      value={leaderPhone}
                      onChange={(e) => setLeaderPhone(e.target.value)}
                      className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                      placeholder="যেমন: +৮৮০ ১৭..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                      ইমেইল (ঐচ্ছিক)
                    </label>
                    <input
                      type="email"
                      value={leaderEmail}
                      onChange={(e) => setLeaderEmail(e.target.value)}
                      className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                      placeholder="example@mail.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    ফোল্ডার / ক্যাটাগরি নির্বাচন করুন
                  </label>
                  <select
                    value={leaderCat}
                    onChange={(e) => setLeaderCat(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm bg-white cursor-pointer"
                  >
                    {customCategories.map((c) => (
                      <option key={c} value={c}>
                        {getCategoryLabel(c)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    প্রোফাইল ছবি লিংক (Image URL)
                  </label>
                  <input
                    type="text"
                    required
                    value={leaderImg}
                    onChange={(e) => setLeaderImg(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm font-mono"
                    placeholder="https://images.unsplash.com/..."
                  />
                </div>

                {leaderImg && (
                  <div className="p-2.5 bg-gray-50 rounded-xl border border-dashed border-gray-200 flex flex-col items-center">
                    <span className="text-[10px] text-gray-400 mb-2">ছবি প্রিভিউ</span>
                    <img
                      src={leaderImg}
                      alt="Leader Preview"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop';
                      }}
                      className="w-20 h-20 rounded-full border border-gray-200 object-cover shadow-sm"
                    />
                  </div>
                )}

                <div className="flex space-x-3 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingLeader(null)}
                    className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-sm font-medium hover:bg-emerald-700 shadow-md"
                  >
                    সংরক্ষণ করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
