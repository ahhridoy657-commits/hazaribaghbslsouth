/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Megaphone, Newspaper, Plus, Edit3, Trash2, Calendar, X, ChevronDown, ChevronUp } from 'lucide-react';
import { Notice, News } from '../types';

interface NoticeBoardProps {
  notices: Notice[];
  onUpdateNotices: (updatedNotices: Notice[]) => void;
  news: News[];
  onUpdateNews: (updatedNews: News[]) => void;
  isAdmin: boolean;
}

export default function NoticeBoard({
  notices,
  onUpdateNotices,
  news,
  onUpdateNews,
  isAdmin,
}: NoticeBoardProps) {
  const [expandedNoticeId, setExpandedNoticeId] = useState<string | null>(null);
  
  // Modals editing states
  const [editingNotice, setEditingNotice] = useState<Notice | null>(null);
  const [editingNews, setEditingNews] = useState<News | null>(null);

  // Form states
  const [noticeTitle, setNoticeTitle] = useState('');
  const [noticeContent, setNoticeContent] = useState('');
  const [noticeDate, setNoticeDate] = useState('');

  const [newsTitle, setNewsTitle] = useState('');
  const [newsContent, setNewsContent] = useState('');
  const [newsImg, setNewsImg] = useState('');
  const [newsDate, setNewsDate] = useState('');

  // Notices Actions
  const openAddNoticeModal = () => {
    setEditingNotice({
      id: `notice-${Date.now()}`,
      title: '',
      content: '',
      date: new Date().toISOString().split('T')[0],
    });
    setNoticeTitle('');
    setNoticeContent('');
    setNoticeDate(new Date().toISOString().split('T')[0]);
  };

  const openEditNoticeModal = (notice: Notice) => {
    setEditingNotice(notice);
    setNoticeTitle(notice.title);
    setNoticeContent(notice.content);
    setNoticeDate(notice.date);
  };

  const saveNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingNotice) return;

    const newNoticeData: Notice = {
      id: editingNotice.id,
      title: noticeTitle,
      content: noticeContent,
      date: noticeDate,
    };

    const exists = notices.some((n) => n.id === editingNotice.id);
    if (exists) {
      onUpdateNotices(notices.map((n) => (n.id === editingNotice.id ? newNoticeData : n)));
    } else {
      onUpdateNotices([newNoticeData, ...notices]);
    }
    setEditingNotice(null);
  };

  const deleteNotice = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('আপনি কি নিশ্চিত যে এই নোটিশটি মুছে ফেলতে চান?')) {
      onUpdateNotices(notices.filter((n) => n.id !== id));
    }
  };

  // News Actions
  const openAddNewsModal = () => {
    setEditingNews({
      id: `news-${Date.now()}`,
      title: '',
      content: '',
      imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=600&auto=format&fit=crop',
      date: new Date().toISOString().split('T')[0],
    });
    setNewsTitle('');
    setNewsContent('');
    setNewsImg('https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=600&auto=format&fit=crop');
    setNewsDate(new Date().toISOString().split('T')[0]);
  };

  const openEditNewsModal = (item: News) => {
    setEditingNews(item);
    setNewsTitle(item.title);
    setNewsContent(item.content);
    setNewsImg(item.imageUrl);
    setNewsDate(item.date);
  };

  const saveNews = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingNews) return;

    const newNewsData: News = {
      id: editingNews.id,
      title: newsTitle,
      content: newsContent,
      imageUrl: newsImg,
      date: newsDate,
    };

    const exists = news.some((n) => n.id === editingNews.id);
    if (exists) {
      onUpdateNews(news.map((n) => (n.id === editingNews.id ? newNewsData : n)));
    } else {
      onUpdateNews([newNewsData, ...news]);
    }
    setEditingNews(null);
  };

  const deleteNews = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('আপনি কি নিশ্চিত যে এই খবরটি মুছে ফেলতে চান?')) {
      onUpdateNews(news.filter((n) => n.id !== id));
    }
  };

  const toggleNotice = (id: string) => {
    setExpandedNoticeId(expandedNoticeId === id ? null : id);
  };

  return (
    <section id="notices" className="py-16 bg-white border-b border-emerald-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid lg:grid-cols-12 gap-10">
          
          {/* Left Column: Notice Board (4 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex justify-between items-center pb-4 border-b-2 border-red-500">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2 font-sans">
                <Megaphone className="text-red-600 animate-bounce" size={24} />
                <span>নোটিশ বোর্ড</span>
              </h2>
              {isAdmin && (
                <button
                  onClick={openAddNoticeModal}
                  className="flex items-center space-x-1 bg-red-50 text-red-700 hover:bg-red-100 font-bold px-3.5 py-1.5 rounded-xl text-xs transition-colors border border-red-200"
                >
                  <Plus size={14} />
                  <span>নতুন নোটিশ</span>
                </button>
              )}
            </div>

            {notices.length === 0 ? (
              <p className="text-gray-500 py-8 text-center text-sm bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                এই মুহূর্তে কোনো নোটিশ নেই।
              </p>
            ) : (
              <div className="space-y-4 max-h-[520px] overflow-y-auto pr-2 custom-scrollbar">
                {notices.map((notice) => {
                  const isExpanded = expandedNoticeId === notice.id;
                  return (
                    <div
                      key={notice.id}
                      onClick={() => toggleNotice(notice.id)}
                      className={`p-4.5 rounded-2xl border transition-all cursor-pointer ${
                        isExpanded
                          ? 'bg-red-50/40 border-red-200 shadow-xs'
                          : 'bg-slate-50 border-gray-100 hover:bg-slate-100/50 hover:border-gray-200'
                      }`}
                    >
                      <div className="flex justify-between items-start gap-4">
                        <div className="space-y-1.5 flex-1">
                          <div className="flex items-center space-x-2 text-xs text-gray-400 font-semibold">
                            <Calendar size={12} className="text-red-500" />
                            <span>{notice.date}</span>
                          </div>
                          <h3 className="text-sm sm:text-base font-bold text-slate-800 leading-snug font-sans">
                            {notice.title}
                          </h3>
                        </div>
                        <button className="text-gray-400 hover:text-emerald-600 mt-1">
                          {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                        </button>
                      </div>

                      {isExpanded && (
                        <div className="mt-4 pt-4 border-t border-red-100 text-gray-600 text-sm leading-relaxed whitespace-pre-line animate-in fade-in duration-250">
                          {notice.content}
                          
                          {isAdmin && (
                            <div className="mt-4 flex space-x-2 justify-end">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openEditNoticeModal(notice);
                                }}
                                className="flex items-center space-x-1 px-3 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg text-xs font-bold"
                              >
                                <Edit3 size={11} />
                                <span>সম্পাদনা</span>
                              </button>
                              <button
                                onClick={(e) => deleteNotice(notice.id, e)}
                                className="flex items-center space-x-1 px-3 py-1 bg-red-50 text-red-700 hover:bg-red-100 rounded-lg text-xs font-bold"
                              >
                                <Trash2 size={11} />
                                <span>মুছুন</span>
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Column: News Section (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex justify-between items-center pb-4 border-b-2 border-emerald-600">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2 font-sans">
                <Newspaper className="text-emerald-700" size={24} />
                <span>সাম্প্রতিক কার্যক্রম ও খবর</span>
              </h2>
              {isAdmin && (
                <button
                  onClick={openAddNewsModal}
                  className="flex items-center space-x-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-bold px-3.5 py-1.5 rounded-xl text-xs transition-colors border border-emerald-200"
                >
                  <Plus size={14} />
                  <span>নতুন খবর</span>
                </button>
              )}
            </div>

            {news.length === 0 ? (
              <p className="text-gray-500 py-12 text-center text-sm bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                এই মুহূর্তে কোনো খবর প্রকাশিত হয়নি।
              </p>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {news.map((item) => (
                  <div
                    key={item.id}
                    className="group relative bg-white rounded-2xl overflow-hidden border border-emerald-50 hover:border-emerald-600/30 hover:shadow-md transition-all duration-300 flex flex-col h-full"
                  >
                    {/* News Image */}
                    <div className="relative h-44 w-full bg-gray-100 overflow-hidden">
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                      />
                      <div className="absolute top-3 left-3 bg-emerald-600 text-white text-[10px] font-bold px-2 py-1 rounded-md shadow-xs flex items-center gap-1">
                        <Calendar size={10} />
                        <span>{item.date}</span>
                      </div>
                    </div>

                    {/* News Details */}
                    <div className="p-4.5 flex-1 flex flex-col justify-between space-y-3">
                      <div className="space-y-1.5">
                        <h3 className="text-sm sm:text-base font-bold text-slate-800 leading-snug font-sans group-hover:text-emerald-700 transition-colors line-clamp-2">
                          {item.title}
                        </h3>
                        <p className="text-gray-500 text-xs sm:text-sm leading-relaxed line-clamp-3">
                          {item.content}
                        </p>
                      </div>

                      {isAdmin && (
                        <div className="pt-3 border-t border-gray-50 flex justify-end space-x-2">
                          <button
                            onClick={() => openEditNewsModal(item)}
                            className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg text-xs font-bold flex items-center gap-1"
                          >
                            <Edit3 size={11} />
                            <span>সম্পাদনা</span>
                          </button>
                          <button
                            onClick={(e) => deleteNews(item.id, e)}
                            className="p-1.5 bg-red-50 text-red-700 hover:bg-red-100 rounded-lg text-xs font-bold flex items-center gap-1"
                          >
                            <Trash2 size={11} />
                            <span>মুছুন</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

        {/* Notice Add/Edit Modal */}
        {editingNotice && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-emerald-100 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <Megaphone size={18} className="text-red-500" />
                  নোটিশ তথ্য সম্পাদনা
                </h3>
                <button
                  onClick={() => setEditingNotice(null)}
                  className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100"
                >
                  <X size={18} />
                </button>
              </div>

              <form onSubmit={saveNotice} className="space-y-4 text-left">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    নোটিশ শিরোনাম
                  </label>
                  <input
                    type="text"
                    required
                    value={noticeTitle}
                    onChange={(e) => setNoticeTitle(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                    placeholder="নোটিশের শিরোনাম লিখুন"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                      প্রকাশের তারিখ
                    </label>
                    <input
                      type="date"
                      required
                      value={noticeDate}
                      onChange={(e) => setNoticeDate(e.target.value)}
                      className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm cursor-pointer"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    নোটিশের মূল বিবরণ
                  </label>
                  <textarea
                    rows={5}
                    required
                    value={noticeContent}
                    onChange={(e) => setNoticeContent(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm resize-none"
                    placeholder="নোটিশের বিস্তারিত বার্তা এখানে লিখুন..."
                  />
                </div>

                <div className="flex space-x-3 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingNotice(null)}
                    className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-sm font-medium hover:bg-emerald-700 shadow-md"
                  >
                    সংরক্ষণ করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* News Add/Edit Modal */}
        {editingNews && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-emerald-100 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <Newspaper size={18} className="text-emerald-600" />
                  খবরের তথ্য সম্পাদনা
                </h3>
                <button
                  onClick={() => setEditingNews(null)}
                  className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100"
                >
                  <X size={18} />
                </button>
              </div>

              <form onSubmit={saveNews} className="space-y-4 text-left">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    খবরের শিরোনাম
                  </label>
                  <input
                    type="text"
                    required
                    value={newsTitle}
                    onChange={(e) => setNewsTitle(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                    placeholder="খবরের আকর্ষণীয় শিরোনাম"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                      তারিখ
                    </label>
                    <input
                      type="date"
                      required
                      value={newsDate}
                      onChange={(e) => setNewsDate(e.target.value)}
                      className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm cursor-pointer"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    খবরের মূল খবর বা বিস্তারিত লেখা
                  </label>
                  <textarea
                    rows={5}
                    required
                    value={newsContent}
                    onChange={(e) => setNewsContent(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm resize-none"
                    placeholder="বিস্তারিত খবরটি এখানে লিখুন..."
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                    খবরের ছবি লিংক (Image URL)
                  </label>
                  <input
                    type="text"
                    required
                    value={newsImg}
                    onChange={(e) => setNewsImg(e.target.value)}
                    className="w-full px-3.5 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm font-mono"
                    placeholder="https://images.unsplash.com/..."
                  />
                </div>

                {newsImg && (
                  <div className="p-2.5 bg-gray-50 rounded-xl border border-dashed border-gray-200 flex flex-col items-center">
                    <span className="text-[10px] text-gray-400 mb-2">খবরের ছবি প্রিভিউ</span>
                    <img
                      src={newsImg}
                      alt="News Preview"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=600&auto=format&fit=crop';
                      }}
                      className="w-full h-28 object-cover rounded-lg shadow-sm"
                    />
                  </div>
                )}

                <div className="flex space-x-3 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingNews(null)}
                    className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-sm font-medium hover:bg-emerald-700 shadow-md"
                  >
                    সংরক্ষণ করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
