/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WebsiteData } from './types';

export const INITIAL_WEBSITE_DATA: WebsiteData = {
  config: {
    logoUrl: 'https://images.unsplash.com/photo-1621640100414-03a0368c8536?q=80&w=200&auto=format&fit=crop', // default placeholder
    bannerTitle: 'হাজারীবাগ থানা ছাত্রলীগ',
    bannerSubtitle: 'বাংলাদেশ ছাত্রলীগ, ঢাকা মহানগর দক্ষিণ',
    visitorCount: 14502,
    contactAddress: 'হাজারীবাগ বাজার, থানা রোড, ঢাকা - ১২০৯',
    contactEmail: 'hazaribaghbcl@gmail.com',
    contactPhone: '+৮৮০ ১৭০০-০০০০০০',
    googleMapEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14609.917578297054!2d90.35414508605792!3d23.729377465611295!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755bf367b8461db%3A0xea8080c920f3a47!2sHazaribagh%2C%20Dhaka!5e0!3m2!1sen!2sbd!4v1700000000000!5m2!1sen!2sbd',
    socialFacebook: 'https://facebook.com',
    socialTwitter: 'https://twitter.com',
    socialYoutube: 'https://youtube.com',
  },
  slides: [
    {
      id: 'slide-1',
      imageUrl: 'https://images.unsplash.com/photo-1599074914978-2946b69e5740?q=80&w=1200&auto=format&fit=crop',
      title: 'ঐতিহাসিক হাজারীবাগ থানা ছাত্রলীগ',
      name: 'বিপ্লবী শুভেচ্ছা ও অভিনন্দন',
      designation: 'জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমানের আদর্শে গড়া ছাত্র সংগঠন'
    },
    {
      id: 'slide-2',
      imageUrl: 'https://images.unsplash.com/photo-1566847438217-76e82d383f84?q=80&w=1200&auto=format&fit=crop',
      title: 'স্মার্ট বাংলাদেশ বিনির্মাণে ছাত্রসমাজ',
      name: 'রূপকল্প ২০৪১ বাস্তবায়ন',
      designation: 'দেশরত্ন শেখ হাসিনার হাতকে শক্তিশালী করতে হাজারীবাগ ছাত্রলীগ সদা প্রস্তুত'
    },
    {
      id: 'slide-3',
      imageUrl: 'https://images.unsplash.com/photo-1600132806370-bf17e65e942f?q=80&w=1200&auto=format&fit=crop',
      title: 'শিক্ষা, শান্তি ও প্রগতি',
      name: 'বাংলাদেশ ছাত্রলীগের মূলনীতি',
      designation: 'ছাত্রলীগের গৌরবময় ইতিহাস ও ঐতিহ্যের ধারাবাহিকতায় হাজারীবাগ থানা'
    }
  ],
  leaders: [
    {
      id: 'leader-d1',
      name: 'রাজিবুল ইসলাম বাপ্পি',
      designation: 'সভাপতি, ঢাকা মহানগর দক্ষিণ ছাত্রলীগ',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop',
      phone: '+৮৮০ ১৭১১-১১১১১১',
      email: 'bappi.dhakasouth@gmail.com',
      category: 'dhaka-south'
    },
    {
      id: 'leader-d2',
      name: 'সজল কুন্ডু',
      designation: 'সাধারণ সম্পাদক, ঢাকা মহানগর দক্ষিণ ছাত্রলীগ',
      imageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=300&auto=format&fit=crop',
      phone: '+৮৮০ ১৭২২-২২২২২২',
      email: 'sajal.dhakasouth@gmail.com',
      category: 'dhaka-south'
    },
    {
      id: 'leader-t1',
      name: 'মোঃ রিফাত হাসান',
      designation: 'সভাপতি, হাজারীবাগ থানা ছাত্রলীগ',
      imageUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=300&auto=format&fit=crop',
      phone: '+৮৮০ ১৭৩৩-৩৩৩৩৩৩',
      email: 'rifat.hazaribagh@gmail.com',
      category: 'thana'
    },
    {
      id: 'leader-t2',
      name: 'আসিফ মাহমুদ সজল',
      designation: 'সাধারণ সম্পাদক, হাজারীবাগ থানা ছাত্রলীগ',
      imageUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=300&auto=format&fit=crop',
      phone: '+৮৮০ ১৭৪৪-৪৪৪৪৪৪',
      email: 'asif.hazaribagh@gmail.com',
      category: 'thana'
    },
    {
      id: 'leader-w14-1',
      name: 'তানভীর আহমেদ শুভ',
      designation: 'সভাপতি, ১৪ নং ওয়ার্ড ছাত্রলীগ',
      imageUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?q=80&w=300&auto=format&fit=crop',
      category: 'ward-14'
    },
    {
      id: 'leader-w14-2',
      name: 'মেহেদী হাসান অন্তর',
      designation: 'সাধারণ সম্পাদক, ১৪ নং ওয়ার্ড ছাত্রলীগ',
      imageUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=300&auto=format&fit=crop',
      category: 'ward-14'
    },
    {
      id: 'leader-w22-1',
      name: 'কাজী আশিকুর রহমান',
      designation: 'সভাপতি, ২২ নং ওয়ার্ড ছাত্রলীগ',
      imageUrl: 'https://images.unsplash.com/photo-1489980508314-941910ded1f4?q=80&w=300&auto=format&fit=crop',
      category: 'ward-22'
    },
    {
      id: 'leader-w22-2',
      name: 'ফয়সাল আহমেদ ইমন',
      designation: 'সাধারণ সম্পাদক, ২২ নং ওয়ার্ড ছাত্রলীগ',
      imageUrl: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?q=80&w=300&auto=format&fit=crop',
      category: 'ward-22'
    }
  ],
  notices: [
    {
      id: 'notice-1',
      title: 'হাজারীবাগ থানা ছাত্রলীগের বিশেষ কর্মী সভা সংক্রান্ত জরুরি নোটিশ',
      date: '২০২৬-০৬-২৫',
      content: 'হাজারীবাগ থানা ছাত্রলীগের সকল সাংগঠনিক ওয়ার্ডের সভাপতি ও সাধারণ সম্পাদককে অবগতির জন্য জানানো যাচ্ছে যে, আগামী ৫ই জুলাই ২০২৬ তারিখে বিকাল ৪টায় স্থানীয় কার্যালয়ে বিশেষ বর্ধিত কর্মী সভা অনুষ্ঠিত হবে। উক্ত সভায় সকলের উপস্থিতি বাধ্যতামূলক।'
    },
    {
      id: 'notice-2',
      title: 'বর্ষা মৌসুমে দেশব্যাপী বৃক্ষরোপণ কর্মসূচি পালন প্রসঙ্গে',
      date: '২০২৬-০৬-২০',
      content: 'কেন্দ্রীয় কমিটির নির্দেশনা মোতাবেক হাজারীবাগ থানার প্রতিটি ওয়ার্ডে কমপক্ষে ৫০০টি ফলজ, বনজ ও ভেষজ চারা রোপণ করার নির্দেশ দেওয়া হলো। বৃক্ষরোপণ শেষে ছবি ও প্রতিবেদন থানা কার্যালয়ে জমা দিতে হবে।'
    },
    {
      id: 'notice-3',
      title: 'নতুন সদস্য ফরম সংগ্রহ ও জমাদান প্রক্রিয়া শুরু',
      date: '২০২৬-০৬-১৫',
      content: 'হাজারীবাগ থানা ছাত্রলীগের ডিজিটাল মেম্বারশিপ কার্যক্রমের আওতায় অনলাইনে নতুন সদস্য সংগ্রহ ফর্ম চালু করা হয়েছে। আগ্রহী ছাত্রসমাজকে আমাদের অফিসিয়াল ওয়েবসাইটের মাধ্যমে আবেদন করার অনুরোধ করা হলো।'
    }
  ],
  news: [
    {
      id: 'news-1',
      title: 'হাজারীবাগে বৃক্ষরোপণ ও চারা বিতরণ কর্মসূচি পালন করল থানা ছাত্রলীগ',
      content: 'মাননীয় প্রধানমন্ত্রী দেশরত্ন শেখ হাসিনার ঘোষিত পরিবেশ বাঁচাও কর্মসূচির অংশ হিসেবে হাজারীবাগ থানা ছাত্রলীগ আজ বিভিন্ন শিক্ষাপ্রতিষ্ঠান ও আবাসিক এলাকায় ৩ শতাধিক বৃক্ষ চারা রোপণ ও সাধারণ মানুষের মাঝে বিনামূল্যে বিতরণ করেছে। অনুষ্ঠানে প্রধান অতিথি হিসেবে উপস্থিত ছিলেন স্থানীয় রাজনৈতিক নেতৃবৃন্দ।',
      imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=600&auto=format&fit=crop',
      date: '২০২৬-০৬-২৮'
    },
    {
      id: 'news-2',
      title: 'দুস্থ ও অসহায় পরিবারের মাঝে ঈদ উপহার সামগ্রী বিতরণ',
      content: 'পবিত্র ঈদ-উল-আযহা উপলক্ষে ঢাকা মহানগর দক্ষিণ ছাত্রলীগের নির্দেশনায় হাজারীবাগ থানা ছাত্রলীগের উদ্যোগে ৫০০ পরিবারের মাঝে চাল, ডাল, তেলসহ ঈদ খাদ্য সামগ্রী বিতরণ করা হয়েছে। থানা ছাত্রলীগের সভাপতি ও সাধারণ সম্পাদক এই ত্রাণ বিতরণের সার্বিক তত্ত্বাবধান করেন।',
      imageUrl: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=600&auto=format&fit=crop',
      date: '২০২৬-০৬-১৫'
    },
    {
      id: 'news-3',
      title: 'জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমানের শাহাদাত বার্ষিকীর প্রস্তুতি সভা',
      content: 'আসন্ন ১৫ই আগস্ট জাতীয় শোক দিবস ও জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমানের শাহাদাত বার্ষিকী যথাযোগ্য মর্যাদায় পালনের লক্ষ্যে হাজারীবাগ থানা ছাত্রলীগ এক প্রস্তুতি সভার আয়োজন করে। সভায় শোক র‍্যালি, রক্তদান কর্মসূচি ও মিলাদ মাহফিলের সিদ্ধান্ত গৃহীত হয়।',
      imageUrl: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?q=80&w=600&auto=format&fit=crop',
      date: '২০২৬-০৬-১০'
    }
  ],
  gallery: [
    {
      id: 'gallery-1',
      title: 'বৃক্ষরোপণ কর্মসূচি ২০২৬',
      imageUrl: 'https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?q=80&w=600&auto=format&fit=crop',
      category: 'বৃক্ষরোপণ',
      type: 'image'
    },
    {
      id: 'gallery-2',
      title: 'ত্রাণ বিতরণ কার্যক্রম',
      imageUrl: 'https://images.unsplash.com/photo-1509099836639-18ba1795216d?q=80&w=600&auto=format&fit=crop',
      category: 'সমাজসেবা',
      type: 'image'
    },
    {
      id: 'gallery-3',
      title: ' কর্মী সভা ও র‍্যালি',
      imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=600&auto=format&fit=crop',
      category: 'রাজনৈতিক',
      type: 'image'
    },
    {
      id: 'gallery-4',
      title: 'রক্তদান কর্মসূচি',
      imageUrl: 'https://images.unsplash.com/photo-1615461066841-6116ecdacdca?q=80&w=600&auto=format&fit=crop',
      category: 'সমাজসেবা',
      type: 'image'
    }
  ],
  customLeaderCategories: [
    'dhaka-south',
    'thana',
    'ward-14',
    'ward-22'
  ],
  customGalleryCategories: [
    'সকল',
    'রাজনৈতিক',
    'সমাজসেবা',
    'বৃক্ষরোপণ'
  ]
};
