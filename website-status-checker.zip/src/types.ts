/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Slide {
  id: string;
  imageUrl: string;
  title: string;
  name: string;
  designation: string;
}

export interface Leader {
  id: string;
  name: string;
  designation: string;
  imageUrl: string;
  phone?: string;
  email?: string;
  category: 'central' | 'dhaka-south' | 'thana' | 'ward-14' | 'ward-22' | string;
}

export interface Notice {
  id: string;
  title: string;
  date: string;
  content: string;
  fileUrl?: string;
}

export interface News {
  id: string;
  title: string;
  content: string;
  imageUrl: string;
  date: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  imageUrl: string;
  category: string;
  type: 'image' | 'video';
  videoUrl?: string;
}

export interface BloodDonor {
  id: string;
  name: string;
  mobile: string;
  bloodGroup: string;
  address: string;
  email?: string;
  comments?: string;
  date: string;
}

export interface MemberApplication {
  id: string;
  name: string;
  fatherMotherName: string;
  dob: string;
  institution: string;
  classYear: string;
  mobile: string;
  email?: string;
  address: string;
  photoUrl?: string;
  nidBirthReg: string;
  status: 'pending' | 'approved' | 'rejected';
  date: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email?: string;
  mobile: string;
  message: string;
  date: string;
}

export interface WebsiteConfig {
  logoUrl: string;
  bannerTitle: string;
  bannerSubtitle: string;
  visitorCount: number;
  contactAddress: string;
  contactEmail: string;
  contactPhone: string;
  googleMapEmbedUrl: string;
  socialFacebook: string;
  socialTwitter: string;
  socialYoutube: string;
}

export interface WebsiteData {
  config: WebsiteConfig;
  slides: Slide[];
  leaders: Leader[];
  notices: Notice[];
  news: News[];
  gallery: GalleryItem[];
  customLeaderCategories: string[];
  customGalleryCategories: string[];
}
